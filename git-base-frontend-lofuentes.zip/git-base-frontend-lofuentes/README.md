



## Angular This Project
1. Angular cli 15.2.0
2. Angular Proyect 13.3.11
3. NodeJS 18.20.0
4. si presenta el error code: 'ERR_OSSL_EVP_UNSUPPORTED' por la version de nodejs -Ejecutar En La Terminal-: $env:NODE_OPTIONS = "--openssl-legacy-provider"
5. Ejecutar con npm start para que el proyecto ejecute la omision ERR_OSSL_EVP_UNSUPPORTED
6. And: ```npm start```
7. Navigate to [localhost:4200](localhost:4200)


### Estructura:

```
md-angular-cli-pro
├── CHANGELOG.md
├── README.md
├── angular-cli.json
├── documentation
│   ├── css
│   └── tutorial-components.html
├── e2e
├── karma.conf.js
├── package-lock.json
├── package.json
├── protractor.conf.js
├── src
│   ├── app
│   │   ├── app.component.html
│   │   ├── app.component.ts
│   │   ├── app.module.ts
│   │   ├── app.routing.ts
│   │   ├── appconfig.service.ts
│   │   ├── home
│   │   │   │  └── home-routing.module.ts
│   │   │   │  └── home.component.css
│   │   │   │  ├── home.component.html
│   │   │   │  └── home.component.ts
│   │   │   │  └── home.module.ts
│   │   │   ├── components.module.ts
│   │   │   ├── components.routing.ts
│   │   ├── layouts
│   │   │   ├── admin
│   │   │   │    ├── admin-layout.component.html
│   │   │   │    ├── admin-layout.component.ts
│   │   ├── Menu
│   │   │   ├── left
│   │   │   │    ├── sidebar.component.html
│   │   │   │    ├── sidebar.component.ts
│   │   │   │    ├── sidebar.module.ts
│   │   │   ├── right
│   │   │   │    ├── fixedplugin.component.css
│   │   │   │    ├── fixedplugin.component.html
│   │   │   │    ├── fixedplugin.component.ts
│   │   │   │    ├── fixedplugin.module.ts
│   │   │   ├── up
│   │   │   │    ├── navbar.component.html
│   │   │   │    ├── navbar.component.ts
│   │   │   │    ├── navbar.module.ts
│   │   ├── pages
│   │   │   ├── login
│   │   │   │    ├── login.component.html
│   │   │   │    ├── login.component.ts
│   │   │   │    ├── login.service.ts
│   │   ├── recursos
│   │   │   │   ├── auth.service.ts
│   │   │   │   ├── authInterceptor.ts
│   │   │   │   ├── cryptoOJ.ts
│   │   │   │   ├── recursosVarios.ts
│   │   ├── shared
│   │   │   ├── footer
│   │   │   │    ├── footer.component.html
│   │   │   │    ├── footer.component.ts
│   │   │   │    ├── footer.module.ts
│   │   ├── md
│   │   │   ├── md-chart
│   │   │   │   ├── md-chart.component.css
│   │   │   │   ├── md-chart.component.html
│   │   │   │   ├── md-chart.component.spec.ts
│   │   │   │   └── md-chart.component.ts
│   │   │   ├── md-table
│   │   │   │   ├── md-table.component.html
│   │   │   │   └── md-table.component.ts
│   │   │   └── md.module.ts
│   ├── assets
│   │   ├── css
│   │   │   ├── bootstrap.min.css
│   │   │   ├── demo.css
│   │   │   ├── material-dashboard.css
│   │   │   ├── material-dashboard.css.map
│   │   │   └── material-dashboard.min.css
│   │   ├── img
│   │   ├── js
│   │   └── sass
│   │       ├── material-dashboard
│   │       └── material-dashboard.scss
│   ├── environments
│   ├── favicon.ico
│   ├── index.html
│   ├── main.ts
│   ├── polyfills.ts
│   ├── styles.css
│   ├── test.ts
│   ├── tsconfig.app.json
│   ├── tsconfig.spec.json
│   └── typings.d.ts
├── tsconfig.json
├── tslint.json
├── typings
└── typings.json

```

# [Angular 16] DEVELOPED BY JESUS DE LEON

