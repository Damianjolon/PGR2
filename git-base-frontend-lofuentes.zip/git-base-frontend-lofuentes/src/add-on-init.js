const fs = require('fs');
const path = require('path');

// Obtener el nombre del componente desde los argumentos de la línea de comandos
const componentName = process.argv[2];

if (!componentName) {
  console.error('Debes proporcionar el nombre del componente.');
  process.exit(1);
}

// Ruta al archivo del componente
const componentPath = path.join(__dirname, `../src/app/${componentName}/${componentName}.component.ts`);

if (fs.existsSync(componentPath)) {
  let content = fs.readFileSync(componentPath, 'utf8');

  // Agregar implements OnInit, constructor y ngOnInit
  content = content.replace(
    'export class',
    `import { OnInit } from '@angular/core';

export class`
  );
  content = content.replace(
    'export class',
    `export class implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }`
  );

  // Guardar los cambios en el archivo
  fs.writeFileSync(componentPath, content);
  console.log(`Se agregó implements OnInit, constructor y ngOnInit a ${componentName}.component.ts`);
} else {
  console.error(`No se encontró el archivo del componente en ${componentPath}`);
}