import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Pipe({
  name: 'httpSafe'
})
export class HttpSafePipe implements PipeTransform {

  constructor(private sanitizer: DomSanitizer) {}

  transform(url: string): SafeResourceUrl {
    // Si la URL comienza con 'http' o 'https', se considera segura.
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    } else {
      // Si la URL no cumple con los protocolos http o https, la devolvemos tal cual.
      return url;
    }
  }
}
