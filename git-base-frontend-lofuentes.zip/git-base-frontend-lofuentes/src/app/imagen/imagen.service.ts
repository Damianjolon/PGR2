import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppconfigService } from 'app/appconfig.service';
@Injectable({
  providedIn: 'root'
})
export class ImagenService {
  constructor(private http: HttpClient,private appSettings:AppconfigService) { }



  VerArchivoNAS(id: string):  any{
    return this.http.get( this.appSettings.restApiServiceBaseUri+'Archivo/file/'+id,
      { responseType: 'blob' });
  }
}

