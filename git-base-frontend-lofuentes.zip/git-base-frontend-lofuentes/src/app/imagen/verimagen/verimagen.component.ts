import { Component, OnInit, OnDestroy } from '@angular/core';
import { ImagenService } from '../imagen.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { map, Observable, startWith } from 'rxjs';
import { DialogComponent } from 'app/componentes/modal/dialogs/dialog/dialog.component';
import { FirmaComponent } from 'app/componentes/modal/dialogs/firma/firma.component';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { ArchivosComponent } from 'app/componentes/modal/dialogs/archivos/archivos.component';

@Component({
  selector: 'app-verimagen',
  templateUrl: './verimagen.component.html',
  styleUrls: ['./verimagen.component.scss']
})
export class VerimagenComponent implements OnInit, OnDestroy {
  fileUrl: SafeUrl | null = null;
  mostrar: boolean = false;
  errorMessage: string | null = null;
  isImage: boolean = false;
  isAudio: boolean = false;
  isPdf: boolean = false;
  isVideo: boolean = false;

//
formulario: FormGroup;
  http!: HttpClient;

  constructor(
    private reportesService: ImagenService,
    private sanitizer: DomSanitizer,private formBuilder: FormBuilder,
    public dialog: MatDialog,
  ) {
     this.formulario = this.formBuilder.group({
      archivo: ['', Validators.required],

    });
  }

  ngOnInit(): void {
//    this.VisualizarDocumentoNAS();
    this.onReset();
    this.formulario.markAllAsTouched();

  }

    AbrirModal(){
      const dialogRef = this.dialog.open(ArchivosComponent, {
        data: this.formulario.value,
        width: '900px',
        panelClass: ["bounce-in-top"],
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log("salio");
        
        //aqui se actualiza con cualquier procedimiento al salir
        
      });
    }
  


  enviar() {

    if (this.formulario.valid) {
     const dialogRef = this.dialog.open(ArchivosComponent, {
        data: this.formulario.value,
        width: '900px',
        panelClass: ["bounce-in-top"],
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log("salio");
        
        //aqui se actualiza con cualquier procedimiento al salir
        
      });
        }
      
  /*     this.errorMessage = null;
      console.log(this.formulario.valid)
      const idArchivo = this.formulario.get('archivo')?.value;
      console.log('ID Archivo:', idArchivo);
      this.VisualizarDocumentoNAS(idArchivo);
    } else {
      this.formulario.markAllAsTouched();

    }
      */
//    this.VisualizarDocumentoNAS('fsdfsdfsd');

  }

    AbrirModalFirma(){
      const dialogRef = this.dialog.open(FirmaComponent, {
        data: { event },
       // width: '400px',
        panelClass: ["bounce-in-top"]
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log("salio");
        
        //aqui se actualiza con cualquier procedimiento al salir
        
      });
    }

      loadFileContent(x: number){
        if(x==1){
          new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/modal.component.html",'language-html'); 
        }else if(x==2){
          new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/modal.component.ts.html",'language-typescript'); 
        }else if(x==3){
          new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/modal.component.scss.html",'language-html'); 
        }
      }

  async VisualizarDocumentoNAS(id: string ) {
    this.reportesService.VerArchivoNAS(id).subscribe({
      next: (response: Blob) => {
        try {

          console.log('Response MIME type:', response.type);
          // Determine file type
          this.isImage = response.type.startsWith('image/');
          this.isAudio = response.type.startsWith('audio/') || response.type === 'audio/mpeg';
          this.isVideo = response.type.startsWith('video/') || response.type === 'application/mp4';
          this.isPdf = response.type === 'application/pdf';
          if (!this.isImage && !this.isVideo && !this.isAudio && !this.isPdf) {
            throw new Error('Tipo de archivo no soportado: ' + response.type);
          }

          const objectUrl = URL.createObjectURL(response);
       // Usar la sanitización adecuada según el tipo de archivo
          if (this.isPdf) {
            this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(objectUrl); // Para <iframe>
          } else {
            this.fileUrl = this.sanitizer.bypassSecurityTrustUrl(objectUrl); // Para <img>, <video>, <audio>
          }

          this.mostrar = true;
        } catch (err) {
          this.errorMessage = 'Error al procesar el archivo: ' + (err instanceof Error ? err.message : 'Error desconocido');
          console.error('Error:', err);
        }
      },
      error: (err: any) => {
        this.errorMessage = 'Error al descargar el archivo: ' + err.message;
        console.error('Error al descargar el archivo:', err);
      }
    });
  }

 



  onReset() {
    this.formulario.reset();
  }
  
  errorHandling(control: string, error: string) {
    //return null
    return this.formulario.get(control)?.hasError(error);
  }




  ngOnDestroy(): void {
    if (this.fileUrl) {
      URL.revokeObjectURL(this.fileUrl as string);
    }
  }
}