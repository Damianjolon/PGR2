
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImagenRoutingModule } from './imagen-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../app.module';
import { SelectModule } from 'ng2-select';


import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';

import { TagInputModule } from 'ngx-chips';
// import { ChartsModule} from 'ng2-charts';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';


import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';

import { VerimagenComponent } from './verimagen/verimagen.component';

import { MatInputModule } from '@angular/material/input';
import { NouisliderModule } from 'ng2-nouislider';
import { DialogComponent } from 'app/componentes/modal/dialogs/dialog/dialog.component';
import { FirmaComponent } from 'app/componentes/modal/dialogs/firma/firma.component';
import { ViewcodeComponent } from 'app/componentes/viewcode/viewcode.component';
import { ArchivosComponent } from 'app/componentes/modal/dialogs/archivos/archivos.component';

@NgModule({
    imports: [
        CommonModule,
        ImagenRoutingModule,
        MaterialModule,
        ReactiveFormsModule,
        FormsModule,
        MatIconModule,
        NouisliderModule,
        TagInputModule,
        MatTableModule,
        MatSelectModule,
        MatFormFieldModule,
        //ChartsModule,
        NgxMatSelectSearchModule,
        NgxExtendedPdfViewerModule,
        MatInputModule
        // MatDatepickerModule
    ],
    declarations: [VerimagenComponent,DialogComponent,FirmaComponent,ViewcodeComponent,ArchivosComponent]
})
export class ImagenesModule { }
