import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { validarPermisos } from 'app/guardAccesos/auth-guard.service';
import { VerimagenComponent } from './verimagen/verimagen.component';



//acceso a las constantes guardadas en loca Storage
var localStorageService = localStorage;
var constantes:any = JSON.parse(atob(localStorageService.getItem("CONSTANTES")!));

const routes: Routes = [

  {
    path: 'VerImagen',
    component: VerimagenComponent,
    //data: {paginas: [constantes.MENU_REPORTES]}, //ID DEL MENU EN OAUTH
    //canActivate:[validarPermisos]
  },

  {
    path: '',
    redirectTo: ''
  },
  // {
  //   path:'Dashboard',
  //   component: DashboardComponent
  // },
  // {
  //   path:'GenerarReportes',
  //   component: ListadoComponent
  // }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ImagenRoutingModule { }
