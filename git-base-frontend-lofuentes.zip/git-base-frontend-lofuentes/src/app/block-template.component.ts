import { Component } from '@angular/core';

@Component({
  selector: 'block-temp',
  styles: [`
    :host {
      text-align: center;
      color: #01579b;
    }
  `],
  template: `
  <div class="block-ui-template">
    <img src="./assets/img/load.gif" style="height:10vh;">      
  </div>
  `
})
export class BlockTemplateComponent { }
