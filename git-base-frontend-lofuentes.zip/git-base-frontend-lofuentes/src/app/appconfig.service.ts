import { EnvironmentInjector, Injectable } from '@angular/core';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AppconfigService {

  constructor() { /* TODO document why this constructor is empty */  }
  
   restApiServiceBaseUri= environment.restApiServiceBaseUri // REST Api
   restOAUTH = environment.restOAUTH
   restAPIEMAIL=environment.restAPIEMAIL
   sistemaId = environment.sistemaId
   sistemaIdOAUTH = environment.sistemaIdOAUTH
   googleMapsApiKey: string = environment.googleMapsApiKey
   recapchaApiKey = environment.recapchaApiKey
   Sistema= environment.Sistema

}
