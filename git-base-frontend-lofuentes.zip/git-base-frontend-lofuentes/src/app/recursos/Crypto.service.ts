import { Injectable } from '@angular/core';
import { cryptoOJ } from './cryptoOJ';

@Injectable({
  providedIn: 'root',
})
export class CryptoService {
  private authkey = new cryptoOJ().sha256("CIT-" + "-D" + new Date().getDate() + "-M" + new Date().getMonth() + "-Y" + new Date().getFullYear() );

  decodeJsonValues(obj: any): any {
    if (typeof obj === "object" && obj !== null) {
      if (Array.isArray(obj)) {
        return obj.map((item) => this.decodeJsonValues(item));
      }

      const decodedObj: any = {};
      Object.entries(obj).forEach(([key, value]) => {
        decodedObj[key] = this.decodeJsonValues(value);
      });
      return decodedObj;
    }

    if (typeof obj === "string") {
      try {
        const decryptedString = new cryptoOJ().decrypt(this.authkey, obj);
        return this.isJsonString(decryptedString)
          ? JSON.parse(decryptedString)
          : decryptedString;
      } catch (error) {
        return obj;
      }
    }
    return obj;
  }

  encodeJsonValues(obj: any): any {
    if (typeof obj === "object" && obj !== null) {
      if (Array.isArray(obj)) {
        return obj.map((item) => this.encodeJsonValues(item));
      }

      const encodedObj: any = {};
      Object.entries(obj).forEach(([key, value]) => {
        encodedObj[key] = this.encodeJsonValues(value);
      });
      return encodedObj;
    }

    if (typeof obj === "string") {
      return new cryptoOJ().encrypt(this.authkey, obj.toString());
    }
    return obj;
  }

  private isJsonString(str: string): boolean {
    try {
      JSON.parse(str);
      return true;
    } catch (e) {
      return false;
    }
  }
}