  export interface Filex extends File {
    //File: any;
    //File: File; // El archivo nativo
    observts: string; // Observaciones o metadata adicional
    /*lastModified: number;
    lastModifiedDate: Date;
    name: string;
    webkitRelativePath: string;*/
    observ: string;
    
  }