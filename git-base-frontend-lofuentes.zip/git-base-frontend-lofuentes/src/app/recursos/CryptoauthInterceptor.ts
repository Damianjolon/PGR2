import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { CryptoService } from './crypto.service';

@Injectable()
export class CryptoauthInterceptor implements HttpInterceptor {
  constructor(private cryptoService: CryptoService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let authReq = req.clone();

    if (req.method === "POST" || req.method === "PUT") {
      if (authReq.body instanceof FormData) {
        let newFormData = new FormData();
        let promises: Promise<void>[] = [];

        authReq.body.forEach((value, key) => {
          console.log(`🔍 Procesando key: ${key}, valor:`, value);
          if (value instanceof File) {
            if (value.type === "application/json") {
              let reader = new FileReader();
              let filePromise = new Promise<void>((resolve) => {
                reader.onload = (event: Event) => { 
                  try {
                    const target = event.target as FileReader; 
                    if (target && target.result) {
                      const result = target.result as string;
                      const jsonData = JSON.parse(result);
                      const encryptedJson = this.cryptoService.encodeJsonValues(jsonData);            
                      const encryptedBlob = new Blob([JSON.stringify(encryptedJson)], { type: "application/json" });
                      newFormData.append(key, encryptedBlob, value.name);
                      
                    } else {
                      newFormData.append(key, value);
                    }
                    resolve();
                  } catch (error) {
                    newFormData.append(key, value);
                    resolve();
                  }
                };
            
                reader.onerror = (error) => {
                  newFormData.append(key, value);
                  resolve();
                };
            
                reader.readAsText(value);
              });
              promises.push(filePromise);
            }else {
              newFormData.append(key, value);
            }
          } else {
            let encryptedValue = this.cryptoService.encodeJsonValues(value);
            newFormData.append(key, JSON.stringify(encryptedValue));
          }
        });

        return from(Promise.all(promises)).pipe(
          switchMap(() => {
            newFormData.forEach((value, key) => {
              console.log(`🔹 ${key}:`, value);
            });

            const updatedRequest = authReq.clone({ body: newFormData });
            return next.handle(updatedRequest);
          })
        );
      } else {
        if (authReq.body) {
          const encryptedBody = this.cryptoService.encodeJsonValues(authReq.body);
          authReq = authReq.clone({ body: encryptedBody });
        }
      }
    }

    return next.handle(authReq);
  }
}