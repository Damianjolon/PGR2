import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { MaterialModule } from "app/app.module";

import { MatIconModule } from "@angular/material/icon";

import { TagInputModule } from "ngx-chips";
import { MatTableModule } from "@angular/material/table";
import { MatSelectModule } from "@angular/material/select";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { NgxMaterialTimepickerModule } from "ngx-material-timepicker";





import { MatButtonModule } from "@angular/material/button";


import { NgxMatSelectSearchModule } from "ngx-mat-select-search";

import { InputsComponent } from "./inputs/inputs.component";
import { FormngmodelComponent } from "./formngmodel/formngmodel.component";
import { FormvalidatorComponent } from "./formvalidator/formvalidator.component";
import { IconsComponent } from "./icons/icons.component";
import { DocumentacionComponent } from "./documentacion/documentacion.component";
import { ModulosComponent } from "./modulos/modulos.component";
import { FormsRoutingModule } from "./forms-routing.module";
import { DatepickeryearComponent } from "./inputs/datepickeryear/datepickeryear.component";

import { NgxMaskDirective, NgxMaskPipe, provideNgxMask } from "ngx-mask";

@NgModule({
  declarations: [
    InputsComponent,
    FormngmodelComponent,
    FormvalidatorComponent,
    DatepickeryearComponent,
    IconsComponent,
    DocumentacionComponent,
    ModulosComponent,
  ],
  imports: [
    //componentes para formularios
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    MatIconModule,
    //NouisliderModule,
    TagInputModule,
    MatTableModule,
    MatSelectModule,
    MatFormFieldModule,

    MatSelectModule,
    NgxMatSelectSearchModule,

    MatInputModule,
    NgxMaterialTimepickerModule,

    //routing
    FormsRoutingModule,

    MatButtonModule,

    //PARA EL RELOJ
    NgxMaterialTimepickerModule,

    //mask
    NgxMaskDirective,
    NgxMaskPipe,
  ],
  providers: [
    provideNgxMask(), // Provee la configuración de ngx-mask
  ],

  bootstrap: [],
})
export class FormsViewModule {}
