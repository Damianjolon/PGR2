import { HttpClient } from "@angular/common/http";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { CodeViewerClass } from "app/recursos/comunes/functions/codeviewer";
import moment from "moment";
import { Observable } from "rxjs";
import { map, startWith } from "rxjs/operators";


@Component({
  selector: "app-inputs",
  templateUrl: "./inputs.component.html",
  styleUrls: ["./inputs.component.scss"],
})
export class InputsComponent {
  
  @ViewChild("timepicker") timepicker: any;

  formValidacionFechas!: FormGroup;
  formValidacionSelect!: FormGroup;
  fecha_Mask = [/[0-9]/, /\d/,'/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/];
  //anioactual: number = new Date().getFullYear();
  date = new FormControl(moment());
  maxDate = new Date();
  minDate = new Date(2024, 0, 1);

  /*catalgo deñ select*/
  catalogoSelect: any = [];
  ctrlSelect = new FormControl();
  filterSelect!: Observable<any[]>;


  constructor(
    private formBuilder: FormBuilder,
    public dialog: MatDialog,
    private http: HttpClient,  ) {

    this.formValidacionFechas = this.formBuilder.group({
      FECHA: ["", Validators.required],
      HORA: ["", Validators.required],
    });

    this.formValidacionSelect = this.formBuilder.group({
      ID_SELECT: ["", Validators.required],
    });
  }

  ngOnInit(): void {
    this.formValidacionFechas.markAllAsTouched(); // esto es para marcar los que son requeridos desde al entrar al form
    this.cargarCatalogo()
  }


  //ACCION PARA ABRIR EL RELOJ
  OpenHour() {
    this.timepicker.open();
  }

  //carga el catalgo 
  cargarCatalogo() {
    var Info = [
      {
        ID_SELECT: "1",
        NOMBRE: "Valor 1",
      },
      {
        ID_SELECT: "2",
        NOMBRE: "Valor 2",
      },
      {
        ID_SELECT: "3",
        NOMBRE: "Valor 3",
      },
    ];

    this.catalogoSelect = Info;
    this.filterSelect = this.ctrlSelect.valueChanges.pipe(
      startWith(""),
      map((value) => this._filterSelect(value))
    );
  }

  // Guardar() {
  //   var info = {
  //     FECHA_HORA:
  //       moment(this.formValidacionFechas.get("FECHA").value).format("DD/MM/YYYY") +
  //       " " +
  //       this.formValidacionFechas.get("HORA").value,
  //   };

  //   console.log("esto va a enviar", info);
  // }

  Accion(){
    console.log("accion");
    
  }


  errorHandlingt(control: string, error: string) {
    return this.formValidacionSelect.get(control)?.hasError(error);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////
  ///                          FILTROS SELECT                                             ///
  ///////////////////////////////////////////////////////////////////////////////////////////
  private _filterSelect(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.catalogoSelect.filter(
      (data: { NOMBRE: string; }) => data.NOMBRE.toLowerCase().indexOf(filterValue) === 0
    );
  }

  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/inputs/inputs.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/inputs/inputs.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/inputs/inputs.component.scss.html",'language-html'); 
    }
  }
  
}
