import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocumentacionComponent } from './documentacion/documentacion.component';
import { FormngmodelComponent } from './formngmodel/formngmodel.component';
import { FormvalidatorComponent } from './formvalidator/formvalidator.component';
import { IconsComponent } from './icons/icons.component';
import { InputsComponent } from './inputs/inputs.component';
import { ModulosComponent } from './modulos/modulos.component';

const routes: Routes = [
  {
    path:'Inputs',
    component: InputsComponent
  },
  {
    path:'FormsNgmodel',
    component: FormngmodelComponent
  },
  {
    path:'FormsValidators',
    component: FormvalidatorComponent
  },
  {
    path:'Icons',
    component: IconsComponent
  },
  {
    path:'Documentacion',
    component: DocumentacionComponent
  },
  {
    path:'Modulos',
    component: ModulosComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormsRoutingModule { }
