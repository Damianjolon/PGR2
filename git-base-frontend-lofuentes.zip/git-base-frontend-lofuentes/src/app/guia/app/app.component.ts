import { HttpClient } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import * as marked from "marked";

@Component({
  selector: "app-app",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent implements OnInit {
  markdownContent: SafeHtml = "";

  constructor(private http: HttpClient, private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    this.http
    .get('assets/app/guia/app/app.txt', { responseType: 'text' })
    .subscribe(
      async (data: string) => {
        const parsed = await (marked.parse(data) as Promise<string>);
        this.markdownContent = this.sanitizer.bypassSecurityTrustHtml(parsed);
      },
      (error) => {
        console.error('Error al cargar el archivo Markdown:', error);
      }
    );
  
    
  }
}
