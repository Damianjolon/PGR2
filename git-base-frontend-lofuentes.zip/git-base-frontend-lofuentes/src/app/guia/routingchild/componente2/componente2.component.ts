import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-componente2',
  templateUrl: './componente2.component.html',
  styleUrls: ['./componente2.component.scss']
})
export class Componente2Component implements OnInit {

  constructor(private router: Router) {}

  ngOnInit(): void {
  }

  regresar() {
    this.router.navigate(['/Guia/Routing_Child']); // Redirige a la ruta padre, que es Componente0
  }
}
