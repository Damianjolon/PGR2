import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { AppconfigService } from "app/appconfig.service";
import { CodeViewerClass } from "app/recursos/comunes/functions/codeviewer";
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { ComponentesService } from "../componentes.service";
import Swal from 'sweetalert2';


@Component({
  selector: "app-recaptcha",
  templateUrl: "./recaptcha.component.html",
  styleUrls: ["./recaptcha.component.scss"]
})
export class RecaptchaComponent{
  formulario: FormGroup;
  hide = true;

  constructor(
    private fb: FormBuilder,
    private recaptchaV3Service: ReCaptchaV3Service,
    private http: HttpClient,
    public dialog: MatDialog,
    private componentesService: ComponentesService,
  ) {
    this.formulario = this.fb.group({
      USUARIO: ["", [Validators.required, Validators.email]],
      CLAVE: ["", [Validators.required, Validators.minLength(3)]],
    });
  }

  validarFormulario() {
    if (this.formulario.valid) {
      this.recaptchaV3Service.execute('submit').subscribe((token: string) => {
        console.log("Token recibido: ", token);
        const formData = { ...this.formulario.value, recaptchaToken: token };
        this.sendTokenToBackend(formData,token);
      });
    } else {
      console.log("Formulario inválido");
    }
  }


  sendTokenToBackend(data: any, recaptchaToken: string) {

    this.componentesService.Re_Captcha(data,recaptchaToken).subscribe(data => {
      if (data.id > 0) {
        this.onReset();
        Swal.fire("Completado", data.msj, "success");
      } else {
        Swal.fire("Error", data.msj, "warning");
      }
    });
  }

  errorHandling(control: string, error: string) {
    return this.formulario.controls[control].hasError(error);
  }

  onReset() {
    this.formulario.reset();
  }

  loadFileContent(x: number) {
    if (x == 1) {
      new CodeViewerClass(this.http, this.dialog).loadFileContent(
        "assets/app/componentes/recaptcha/recaptcha.component.html",
        "language-html"
      );
    } else if (x == 2) {
      new CodeViewerClass(this.http, this.dialog).loadFileContent(
        "assets/app/componentes/recaptcha/recaptcha.component.ts.html",
        "language-typescript"
      );
    } else if (x == 3) {
      new CodeViewerClass(this.http, this.dialog).loadFileContent(
        "assets/app/componentes/recaptcha/recaptcha.component.scss.html",
        "language-html"
      );
    }
  }
}
