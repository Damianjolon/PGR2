import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { ComponentesService } from '../componentes.service';

@Component({
  selector: 'app-ver-documento',
  templateUrl: './ver-documento.component.html',
  styleUrls: ['./ver-documento.component.scss']
})
export class VerDocumentoComponent implements OnInit {
  Url!:Blob
  fileUrl: any;
  id_file:number = 1;
  
  constructor(
    private componentesService: ComponentesService,
    public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit() {
    this.VisualizarDocumento();
  }


  async VisualizarDocumento() {
      this.componentesService.VerDocumento(this.id_file).subscribe((response: Blob) => {  
      this.Url =response
      }, (error: any) => {
        console.error('Error al descargar el archivo:', error);
      });
    }

    loadFileContent(x: number){
      if(x==1){
        new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/ver-documento/ver-documento.component.html",'language-html'); 
      }else if(x==2){
        new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/ver-documento/ver-documento.component.ts.html",'language-typescript'); 
      }else if(x==3){
        new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/ver-documento/ver-documento.component.scss.html",'language-html'); 
      }
    }
}
