import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-simple',
  templateUrl: './simple.component.html',
  styleUrls: ['./simple.component.scss']
})
export class SimpleComponent implements OnInit {
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('matTable', { static: true }) table!: MatTable<any>;

  dataSource = new MatTableDataSource<any>();
  data: any = [];
  columns: any = [];
  displayedColumns: any;

  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
    this.Inicio();
  }


  Inicio(){
    this.columns = [
    { columnDef: 'rownum', header: 'No.', cell: (element: any) => `${element.rownum}` },
    { columnDef: 'COLUMNA1', header: 'Columna No. 1', cell: (element: any) => `${element.COLUMNA1}` },
    { columnDef: 'COLUMNA2', header: 'Columna No. 2', cell: (element: any) => `${element.COLUMNA2}` },
    { columnDef: 'COLUMNA3', header: 'Columna No. 3', cell: (element: any) => `${element.COLUMNA3}` },
    ]

    //AQUI SE LLAMA EL SERVICIO PARA OBTENER EL ARRAY
    // await this.gestionService.ExpedienteAsignado(data).subscribe(data => {
    //   this.displayedColumns = this.columns.map(c => c.columnDef);
    //   this.dataSource = new MatTableDataSource<any>(data.data);
    //   this.dataSource.paginator = this.paginator;
    //   this.dataSource.sort = this.sort;
    // });

    var data = [
      {
        COLUMNA1:"COLUMNA1",
        COLUMNA2:"COLUMNA2",
        COLUMNA3:"COLUMNA3",
        
      },
      {
        COLUMNA1:"COLUMNA4",
        COLUMNA2:"COLUMNA5",
        COLUMNA3:"COLUMNA6",
        
      }
    ]

    this.displayedColumns = this.columns.map((c: { columnDef: any; }) => c.columnDef)
    this.dataSource = new MatTableDataSource<any>(data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }


  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    console.log(this.dataSource.filter);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tablas/simple/simple.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tablas/simple/simple.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tablas/simple/simple.component.scss.html",'language-html'); 
    }
  }

}

