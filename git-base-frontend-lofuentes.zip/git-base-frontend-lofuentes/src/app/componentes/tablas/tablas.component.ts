import { HttpClient } from "@angular/common/http";
import { Component, OnInit, ViewChild } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { CodeViewerClass } from "app/recursos/comunes/functions/codeviewer";
import { ConselectinputComponent } from "./conselectinput/conselectinput.component";
import { SimpleComponent } from "./simple/simple.component";
import { SinselectinputComponent } from "./sinselectinput/sinselectinput.component";

@Component({
  selector: "app-tablas",
  templateUrl: "./tablas.component.html",
  styleUrls: ["./tablas.component.scss"],
})
export class TablasComponent implements OnInit {
  @ViewChild(ConselectinputComponent, { static: true })ConselectinputComponent!: ConselectinputComponent;
  @ViewChild(SinselectinputComponent, { static: true })SinselectinputComponent!: SinselectinputComponent;
  @ViewChild(SimpleComponent, { static: true })SimpleComponent!: SimpleComponent;

  
  constructor(public dialog: MatDialog,
    private http: HttpClient,
	) {}

  ngOnInit(): void {}

  TabSeleccionado(event: { index: any; }) {
    switch (event.index) {
      case 0:
        this.ConselectinputComponent.Inicio();
        break;
      case 1:
        this.ConselectinputComponent.Inicio();
        break;
        case 2:
          this.SimpleComponent.Inicio();
        break;
      default:
        this.ConselectinputComponent.Inicio();
        break;
    }
  }

  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tablas/tablas.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tablas/tablas.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tablas/tablas.component.scss.html",'language-html'); 
    }
  }
}
