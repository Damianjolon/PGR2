import {
  Component,
  ChangeDetectionStrategy,
  ViewChild,
  TemplateRef,
  OnInit,
  Injector,
} from "@angular/core";
import {
  startOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours,
} from "date-fns";
import { Subject } from "rxjs";
import {
  CalendarEvent,
  CalendarView,
} from "angular-calendar";

import moment from "moment";
import { DetailCalendarComponent } from "./dialogs/detail/detailCalendar.component";
import { MatDialog } from "@angular/material/dialog";
import { CodeViewerClass } from "app/recursos/comunes/functions/codeviewer";
import { HttpClient } from "@angular/common/http";

const colors: any = {
  red: {
    primary: "#ad2121",
    secondary: "#FAE3E3",
  },
  blue: {
    primary: "#1e90ff",
    secondary: "#D1E8FF",
  },
  yellow: {
    primary: "#e3bc08",
    secondary: "#FDF1BA",
  },
};

@Component({
  selector: "app-calendario",
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: "./calendario.component.html",
  styleUrls: ["./calendario.component.scss"],
})
export class CalendarioComponent implements OnInit {
  private yesterday!: Date;
  @ViewChild("modalContent")modalContent!: TemplateRef<any>;
  view: CalendarView = CalendarView.Month;
  CalendarView = CalendarView;
  viewDate: Date = new Date();
  data_Events: any = [];
  //refresh: Subject<any> = new Subject();
  events: CalendarEvent[] = [];
  activeDayIsOpen: boolean = false;
  refresh = new Subject<void>();

  constructor(
    public dialog: MatDialog,
    private http: HttpClient,
    private injector: Injector
  ) { }

  ngOnInit(): void {
    this.ObtenerEventos();
  }

  async ObtenerEventos() {
    this.events = [
      {
        start: subDays(startOfDay(new Date()), 1),
        end: addDays(new Date(), 1),
        title: "A 3 day event",
        color: colors.red,
        allDay: true,
        resizable: {
          beforeStart: true,
          afterEnd: true,
        },
        draggable: true,
      },
      {
        start: startOfDay(new Date()),
        title: "An event with no end date",
        color: colors.yellow,
      },
      {
        start: subDays(endOfMonth(new Date()), 3),
        end: addDays(endOfMonth(new Date()), 3),
        title: "A long event that spans 2 months",
        color: colors.blue,
        allDay: true,
      },
      {
        start: addHours(startOfDay(new Date()), 2),
        end: new Date(),
        title: "A draggable and resizable event",
        color: colors.yellow,
        resizable: {
          beforeStart: true,
          afterEnd: true,
        },
        draggable: true,
      },
    ];

    this.CargarEventos(this.events);
  }

  CargarEventos(Events: any[]) {
    Events.forEach((evento) => {
      const calendarEvent: CalendarEvent = {
        id: evento.id,
        title: evento.title,
        color: colors.blue,
        // color: {
        //   primary: new recursosVarios().obtenerColorAleatorio().clave,
        //   secondary: colors.gray,
        // },
        start: moment(evento.start).toDate(), //new Date(evento.FECHA_VISTA)
        end: moment(evento.end).toDate(),
        //  actions: [
        //     {
        //       label: '<i class="fa fa-fw fa-pencil text-white" ></i>',
        //       onClick: ({ event }: { event: CalendarEvent }): void => {
        //         console.log('Edit event', event);
        //       }
        //     }
        //   ]
      };
      this.events.push(calendarEvent);
    });

    this.refresh.next();
  }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    if (isSameMonth(date, this.viewDate)) {
      this.viewDate = date;
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
    }
  }

  handleEvent(action: string, event: CalendarEvent): void {
    const dialogRef = this.dialog.open(DetailCalendarComponent, {
      data: { event },
      panelClass: ["bounce-in-top"],
    });
    dialogRef.afterClosed().subscribe((result) => {
      this.refresh.next();
      this.activeDayIsOpen = false;
    });
  }

  setView(view: CalendarView) {
    this.view = view;
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }

  loadFileContent(x: number) {
    if (x == 1) {
      new CodeViewerClass(this.http, this.dialog).loadFileContent(
        "assets/app/componentes/calendario/calendario.component.html",
        "language-html"
      );
    } else if (x == 2) {
      new CodeViewerClass(this.http, this.dialog).loadFileContent(
        "assets/app/componentes/calendario/calendario.component.ts.html",
        "language-typescript"
      );
    } else if (x == 3) {
      new CodeViewerClass(this.http, this.dialog).loadFileContent(
        "assets/app/componentes/calendario/calendario.component.scss.html",
        "language-html"
      );
    }
  }
}
