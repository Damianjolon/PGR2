import { NestedTreeControl } from '@angular/cdk/tree';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';

interface RechazoNode {
  TIPO_PADRE?: string;
  TIPO_HIJO?: string;
  HIJOS?: RechazoNode[];
}


@Component({
  selector: 'app-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss']
})
export class TreeComponent implements OnInit {
  
  treeControl = new NestedTreeControl<RechazoNode>(node => node.HIJOS);
  Detalle: any = [];

  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
    this.cargarInfo();
  }

  cargarInfo() {
    var info =[
      {
          "TIPO_PADRE": "PADRE 1",
          "HIJOS": [
              {
                  "ID_HIJO": "2",
                  "TIPO_HIJO": "Hijo 1.",
                  "ID_PADRE": "1"
              }
          ],
          "ID_PADRE": "1"
      },
      {
        "TIPO_PADRE": "PADRE 2",
        "HIJOS": [
            {
                "ID_HIJO": "3",
                "TIPO_HIJO": "Hijo 2",
                "ID_PADRE": "2"
            },
            
              {
                "TIPO_PADRE": "HIJO -PADRE 2",
                "HIJOS": [
                    {
                        "ID_HIJO": "3",
                        "TIPO_HIJO": "Nieto 1",
                        "ID_PADRE": "2"
                    },
                    {
                    
                        "ID_HIJO": "3",
                        "TIPO_HIJO": "Nieto 2",
                        "ID_PADRE": "2"
                    
                    }
                ],
                "ID_PADRE": "2"
            }
            
        ],
        "ID_PADRE": "2"
    },
  ]

    this.Detalle = info;
  }


  getDataSource(data: RechazoNode[]): MatTreeNestedDataSource<RechazoNode> {
    const dataSource = new MatTreeNestedDataSource<RechazoNode>();
    dataSource.data = data;
    return dataSource;
  }

  hasChild = (_: number, node: RechazoNode) => !!node.HIJOS && node.HIJOS.length > 0;




  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tree/tree.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tree/tree.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tree/tree.component.scss.html",'language-html'); 
    }
  }
  
}
