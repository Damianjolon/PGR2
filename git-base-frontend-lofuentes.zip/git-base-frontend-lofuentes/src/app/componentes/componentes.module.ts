import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { MaterialModule } from "app/app.module";
import { MatIconModule } from "@angular/material/icon";
import { TagInputModule } from "ngx-chips";
import { MatTableModule } from "@angular/material/table";
import { MatSelectModule } from "@angular/material/select";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { NgxMaterialTimepickerModule } from "ngx-material-timepicker";
import { CalendarModule, DateAdapter } from "angular-calendar";
import { adapterFactory } from "angular-calendar/date-adapters/date-fns";
import { ModalComponent } from "./modal/modal.component";
import { VerDocumentoComponent } from "./ver-documento/ver-documento.component";
import { CargarDocumentoComponent } from "./cargar-documento/cargar-documento.component";
import { ComponentesRoutingModule } from "./componentes-routing.module";
import { MatCardModule } from "@angular/material/card";
import { Vistaprevia_imagenComponent } from "../recursos/comunes/view/vistaprevia_imagen/vistaprevia_imagen.component";
import { TablasComponent } from "./tablas/tablas.component";
import { TabsComponent } from "./tabs/tabs.component";
import { TimelineComponent } from "./timeline/timeline.component";
import { Componentes1Component } from "./tabs/componentes1/componentes1.component";
import { Componentes2Component } from "./tabs/componentes2/componentes2.component";
import { Componentes3Component } from "./tabs/componentes3/componentes3.component";
import { ConselectinputComponent } from "./tablas/conselectinput/conselectinput.component";
import { SinselectinputComponent } from "./tablas/sinselectinput/sinselectinput.component";
import { SimpleComponent } from "./tablas/simple/simple.component";
import { ChartComponent } from "./chart/chart.component";
import { TreeComponent } from "./tree/tree.component";
import { MatTreeModule } from "@angular/material/tree";
import { CarouselComponent } from "./carousel/carousel.component";
import { MapsComponent } from "./maps/maps.component";
import { EmailComponent } from "./email/email.component";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { GoogleMapsModule } from "@angular/google-maps";
import { AlertaComponent } from "./alerta/alerta.component";
import { StepperComponent } from "./stepper/stepper.component";
import { MatStepperModule } from "@angular/material/stepper";
import { MatButtonModule } from "@angular/material/button";
import { NgxMatSelectSearchModule } from "ngx-mat-select-search";
import { CalendarioComponent } from "./calendario/calendario.component";
import { DetailCalendarComponent } from "./calendario/dialogs/detail/detailCalendar.component";
import { DialogComponent } from "./modal/dialogs/dialog/dialog.component";
import { FirmaComponent } from "./modal/dialogs/firma/firma.component";
import { ViewcodeComponent } from "./viewcode/viewcode.component";
import { NgChartsModule } from "ng2-charts";
import { RecaptchaComponent } from "./recaptcha/recaptcha.component";
import { RecaptchaV3Module, RECAPTCHA_V3_SITE_KEY } from "ng-recaptcha";
import { NgxExtendedPdfViewerModule } from "ngx-extended-pdf-viewer";
import { ArchivosComponent } from './modal/dialogs/archivos/archivos.component';

@NgModule({
  declarations: [
    CalendarioComponent,
    ModalComponent,
    DetailCalendarComponent,
    VerDocumentoComponent,
    CargarDocumentoComponent,
    Vistaprevia_imagenComponent,
    TablasComponent,
    TabsComponent,
    TimelineComponent,
    Componentes1Component,
    Componentes2Component,
    Componentes3Component,
    ConselectinputComponent,
    SinselectinputComponent,
    SimpleComponent,
    ChartComponent,
    TreeComponent,
    CarouselComponent,
    MapsComponent,
    EmailComponent,
    DialogComponent,
    FirmaComponent,
    AlertaComponent,
    ViewcodeComponent,
    StepperComponent,
    RecaptchaComponent,
    ArchivosComponent,
  ],
  imports: [
    //componentes para formularios
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    MatIconModule,
    //NouisliderModule,
    TagInputModule,
    MatTableModule,
    MatSelectModule,
    MatFormFieldModule,

    MatSelectModule,
    NgxMatSelectSearchModule,

    MatInputModule,
    NgxMaterialTimepickerModule,

    //routing
    ComponentesRoutingModule,

    //calendario
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),

    //pdffviewer
    NgxExtendedPdfViewerModule,

    MatCardModule,

    //Tree
    MatTreeModule,

    //carousel
    NgbModule,

    //google maps
    GoogleMapsModule,

    MatStepperModule,
    MatButtonModule,
     
    //chatjs
    NgChartsModule,

    //Recaptcha
    RecaptchaV3Module,
  ],
  //entryComponents:[],
  bootstrap: [],
  providers: [
    {
      provide: RECAPTCHA_V3_SITE_KEY,
      useValue: "6LcX0vQqAAAAAEZZBXm0sx9oz9HgREElugL-Nkpi",
    },
  ],
})
export class ComponentesModule {}
