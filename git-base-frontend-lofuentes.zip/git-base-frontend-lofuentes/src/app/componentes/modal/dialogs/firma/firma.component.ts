import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AppconfigService } from 'app/appconfig.service';
import { AuthService } from 'app/recursos/auth.service';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { FIRMANTE } from 'app/recursos/comunes/Interface/Firmante';
import { recursosVarios } from 'app/recursos/recursosVarios';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-firma',
  templateUrl: './firma.component.html',
  styleUrls: ['./firma.component.scss']
})
export class FirmaComponent implements OnInit {
  formulario: FormGroup;
  disabled = true;
  id_solicitud: string;
  id_sistema: string;
  fecha_actual: Date;
  nombresFirmantes: string[] = [];
  public firmantes:FIRMANTE[] = [];
  hide=true;
  avatar='';
  USUARIO;
  PIN='';
  justificacion='';
  


  constructor(private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<FirmaComponent>,
    private authService: AuthService,
    private appSettings:AppconfigService,
    public dialog: MatDialog,
    private http: HttpClient,
    //private firmasService: FirmasService,
    @Inject(MAT_DIALOG_DATA) public tipoFirma: any) {
    this.avatar='data:image/png;base64,'+this.authService.getsession().SESSION.FOTO;
    this.USUARIO=this.authService.getsession().SESSION.USUARIO; 

    this.formulario = this.formBuilder.group({
      PIN: ["", Validators.required],
    });
  }


ngOnInit(): void {
  
}


  Firmar(){
    if (!this.formulario.valid) {
      new recursosVarios().showNotification('top', 'right', '<h4>Error!! Debe Completar el Formulario</h4>', 4)
      return;
    }
    else {
      let objPin
      this.fecha_actual = new Date();
      objPin = {
        usuario: "usuario",//this.appSettings.usuarioRRHH,
       contrasenia: "btoa(this.appSettings.contraseniaRRHH),",//btoa(this.appSettings.contraseniaRRHH),
       sistema: 37,// pruebas id=37
       cadena: "Random"/*'SEFI=>'+tipo+' de Documento:'
       + this.id_solicitud
       + '=>Fecha:' + this.fecha_actual
       + '=>Usuario:' + this.appSettings.usuarioRRHH*/
     };



     Swal.fire({
      title: "Firmado Exitosamente",
      text: "Puede continuar con el proceso!",
      icon: "success"
    });
    } 
  }

  cerrarModal(): void {
    this.dialogRef.close();
  }

  onReset() {
    this.formulario.reset()
  }


  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/dialogs/firma/firma.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/dialogs/firma/firma.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/dialogs/firma/firma.component.scss.html",'language-html'); 
    }
  }

}
