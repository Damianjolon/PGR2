import { Component, Inject, OnInit } from '@angular/core';
import { DialogComponent } from '../dialog/dialog.component';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ImagenService } from 'app/imagen/imagen.service';

@Component({
  selector: 'app-archivos',
  templateUrl: './archivos.component.html',
  styleUrls: ['./archivos.component.scss']
})
export class ArchivosComponent implements OnInit {
  fileUrl: SafeUrl | null = null;
  mostrar: boolean = false;
  fileUrl2: string | null = null;
  errorMessage: string | null = null;
  isImage: boolean = false;
  isAudio: boolean = false;
  isPdf: boolean = false;
  isVideo: boolean = false;
  isMobile: boolean = false;

  formulario: FormGroup;
  http!: HttpClient;
  constructor(public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog,
    private formBuilder: FormBuilder,
    private sanitizer: DomSanitizer,
    private reportesService: ImagenService) {
    this.formulario = this.formBuilder.group({
      archivo: ['', Validators.required],

    });

  }



  ngOnInit(): void {
    this.isMobile = window.innerWidth <= 600;
    window.addEventListener('resize', () => {
      this.isMobile = window.innerWidth <= 600;
    });

    this.VisualizarDocumentoNAS(this.data.archivo);

    this.onReset();
    this.formulario.markAllAsTouched();

    console.log("data", this.data.archivo);

  }

  Guardar() {
    Swal.fire({
      title: "Guardado Exitosamente",
      text: "Puede continuar con el proceso!",
      icon: "success"
    });
  }


  downloadPdf() {
    if (this.fileUrl2) {
      const link = document.createElement('a');
      link.href = this.fileUrl2;
      link.download = 'document.pdf'; // You can customize the filename
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }
  cerrarModal(): void {
    this.dialogRef.close();
  }

  onReset() {
    this.formulario.reset();
    this.mostrar = false;
    this.fileUrl = null;
    this.fileUrl2 = null;
    this.isImage = false;
    this.isAudio = false;
    this.isPdf = false;
    this.isVideo = false;

    this.errorMessage = null;
  }


  async VisualizarDocumentoNAS(id: string) {
    this.reportesService.VerArchivoNAS(id).subscribe({
      next: (response: Blob) => {
        try {

          console.log('Response MIME type:', response.type);
          this.isImage = response.type.startsWith('image/');
          this.isAudio = response.type.startsWith('audio/') || response.type === 'audio/mpeg';
          this.isVideo = response.type.startsWith('video/') || response.type === 'application/mp4';
          this.isPdf = response.type === 'application/pdf';
          if (!this.isImage && !this.isVideo && !this.isAudio && !this.isPdf) {
            throw new Error('Tipo de archivo no soportado: ' + response.type);
          }

          const objectUrl = URL.createObjectURL(response);
          this.fileUrl2 = objectUrl;
          if (this.isPdf && this.isMobile) {

            this.downloadPdf();
            this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(objectUrl);
            this.dialogRef.close();
          } else if (this.isPdf) {

            this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(objectUrl);
          } else {

            this.fileUrl = this.sanitizer.bypassSecurityTrustUrl(objectUrl);
          }

          this.mostrar = true;
        } catch (err) {
          this.errorMessage = 'Error al procesar el archivo: ' + (err instanceof Error ? err.message : 'Error desconocido');
          console.error('Error:', err);
        }
      },
      error: (err: any) => {
        this.errorMessage = 'Error al descargar el archivo: ' + err.message;
        console.error('Error al descargar el archivo:', err);
      }
    });


  }
}
