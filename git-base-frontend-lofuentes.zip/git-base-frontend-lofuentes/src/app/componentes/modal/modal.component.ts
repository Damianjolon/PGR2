import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { DialogComponent } from './dialogs/dialog/dialog.component';
import { FirmaComponent } from './dialogs/firma/firma.component';


@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {

  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
  }

  AbrirModal(){
    const dialogRef = this.dialog.open(DialogComponent, {
      data: { event },
      panelClass: ["bounce-in-top"],
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log("salio");
      
      //aqui se actualiza con cualquier procedimiento al salir
      
    });
  }

  AbrirModalFirma(){
    const dialogRef = this.dialog.open(FirmaComponent, {
      data: { event },
      panelClass: ["bounce-in-top"]
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log("salio");
      
      //aqui se actualiza con cualquier procedimiento al salir
      
    });
  }

  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/modal.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/modal.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/modal/modal.component.scss.html",'language-html'); 
    }
  }
}
