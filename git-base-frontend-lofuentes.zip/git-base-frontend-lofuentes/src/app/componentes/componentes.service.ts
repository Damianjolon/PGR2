import { catchError } from 'rxjs/operators';
import { recursosVarios } from './../recursos/recursosVarios';
import { Observable, of } from 'rxjs';
import { AppconfigService } from './../appconfig.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ComponentesService {

  constructor(private http: HttpClient, private appSettings: AppconfigService) { }


  VerDocumento(id_file: string | number,):  any{
    return this.http.get( this.appSettings.restApiServiceBaseUri+'File/documento/'+id_file+'/VerDocumento',
      { responseType: 'blob' });
  }

  InsDocumento(dato: FormData): Observable<any>{
    let headers = new HttpHeaders();//esto es necesario para el envio de los files
    return this.http.post<any>(this.appSettings.restApiServiceBaseUri+'File/InsDocumento',dato,{headers})
    .pipe(
      catchError(this.handleError('InsDocumento', []))
    );
  }

  EnviarEmailAWS(data: any): Observable<any>{
    return this.http.post<any>(this.appSettings.restAPIEMAIL+'EmailAWS/SendMail',data)
    .pipe(
      catchError(this.handleError('EnviarEmailAWS', []))
    );
  }

  EnviarEmailSinAWS(data: any): Observable<any>{
    return this.http.post<any>(this.appSettings.restAPIEMAIL+'Email/SendMail',data)
    .pipe(
      catchError(this.handleError('EnviarEmailSinAWS', []))
    );
  }


  Re_Captcha(data: any,gtoken: any): Observable<any>{
    let headers = new HttpHeaders({
      'X-Recaptcha-Token': gtoken
    });
    return this.http.post<any>(this.appSettings.restApiServiceBaseUri+'Example/Re_Captcha',data,{headers})
    .pipe(
      catchError(this.handleError('Re_Captcha', []))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      new recursosVarios().showNotification('top', 'right', '<h4>Error Metodo ' + operation.toString() + '</h3>', 4)
      return of(result as T);
    };
  }

}
