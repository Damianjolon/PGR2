import { HttpClient } from "@angular/common/http";
import {
  Component,
  OnInit,
  ViewChild,
} from "@angular/core";

import { MapInfoWindow, MapMarker } from "@angular/google-maps";
import { MatDialog } from "@angular/material/dialog";
import { CodeViewerClass } from "app/recursos/comunes/functions/codeviewer";

@Component({
  selector: "app-maps",
  templateUrl: "./maps.component.html",
  styleUrls: ["./maps.component.scss"],
})
export class MapsComponent implements OnInit {
  @ViewChild(MapInfoWindow) infoWindow!: MapInfoWindow;

  datos:any={}
  display: any;
  iconUrl: string = "assets/img/aca.png"; //icono que se muetra en el mapa (maker)
  center!: google.maps.LatLngLiteral;
  zoom = 18;

  
  constructor( public dialog: MatDialog,
    private http: HttpClient,) {}

  ngOnInit(): void {
    //datos para el info
    this.datos = {
      title : "Este es un titulo",
      direccion : "Dirección del punto",
      img : "assets/img/palacio.jpg",
      telefono : "1234-5678"
    }

    //datos de longitud y  latidud para mostrar en el mapa
    this.center =  { 
      lat: 14.91167, 
      lng: -91.36111 
    };
    
  }

  // Función para mover el mapa
  moveMap(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.center = event.latLng.toJSON();
  }

  // Movimiento del mouse sobre el mapa
  move(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.display = event.latLng.toJSON();
  }

  //funcion para abrir notificacion con informacion
  openInfoWindow(marker: MapMarker) {
      this.infoWindow.open(marker);

  }

  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/maps/maps.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/maps/maps.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/maps/maps.component.scss.html",'language-html'); 
    }
  }
}
