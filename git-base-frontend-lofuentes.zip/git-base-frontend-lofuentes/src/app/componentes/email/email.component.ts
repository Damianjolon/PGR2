import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { ComponentesService } from "../componentes.service";

@Component({
  selector: "app-email",
  templateUrl: "./email.component.html",
  styleUrls: ["./email.component.scss"],
})
export class EmailComponent implements OnInit {
  formulario: FormGroup;
  data:any={};

  constructor(
    private formBuilder: FormBuilder,
    private componentesService: ComponentesService
  ) {
    this.formulario = this.formBuilder.group({
      email: ["", Validators.required],
    });
  }

  ngOnInit(): void {}

  Enviar() {
    this.data.jsonemail = {
      ID_EMAIL: "3",
      ID_SISTEMA: "52",
      DESTINO: this.formulario.get("email")?.value,
      DESTINO_CC: "jadeleons@oj.gob.gt",
      ASUNTO: "Prueba",
      TITULO: "Este Es el Titulo",
      CUERPO:
        "Este es el contenido del correo electrónico dentro de una tarjeta con un escudo en el header y un banner en el footer.",
      LINK: [
        {
          URL: "http://google.com.gt/",
          TYPE: "B",
          TEXT: "Boton con link a Google",
        },
        {
          URL: "http://portal.oj.gob.gt/",
          TYPE: "T",
          TEXT: "Boton con link a oj",
        },
        {
          URL: "http://youtube.com",
          TYPE: "B",
          TEXT: "Youtube",
        },
      ],
    };

    this.componentesService
      .EnviarEmailSinAWS(this.data.jsonemail)
      .subscribe((data) => {
        if (data.id > 0) {
          Swal.fire("Enviado", "Correo Enviado con Exito", "success");
        }else{
          Swal.fire("Error", data.msj, "warning");
        }
      });
  }

  EnviarAWS() {
    this.data.jsonemail = {
      ID_EMAIL: "1",
      ID_SISTEMA: "52",
      DESTINO: this.formulario.get("email")?.value,
      DESTINO_CC: "jadeleons@oj.gob.gt",
      ASUNTO: "Prueba",
      TITULO: "Este Es el Titulo",
      CUERPO:
        "Este es el contenido del correo electrónico dentro de una tarjeta con un escudo en el header y un banner en el footer.",
      LINK: [
        {
          URL: "http://google.com.gt/",
          TYPE: "B",
          TEXT: "Boton con link a Google",
        },
        {
          URL: "http://portal.oj.gob.gt/",
          TYPE: "T",
          TEXT: "Boton con link a oj",
        },
        {
          URL: "http://youtube.com",
          TYPE: "B",
          TEXT: "Youtube",
        },
      ],
    };

    this.componentesService
      .EnviarEmailAWS(this.data.jsonemail)
      .subscribe((data) => {
        if (data.id > 0) {
          Swal.fire("Enviado", "Correo Enviado con Exito", "success");
        }else{
          Swal.fire("Error", data.msj, "warning");
        }
      });
  }

  onReset() {
    this.formulario.reset();
  }

  errorHandling(control: string, error: string) {
    return this.formulario.get(control)?.hasError(error);
  }
}
