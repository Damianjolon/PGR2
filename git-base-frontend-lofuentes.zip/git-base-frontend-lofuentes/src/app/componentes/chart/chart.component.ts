import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import pluginDataLabels from 'chartjs-plugin-datalabels';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent implements OnInit {


/*BAR VARIABLE*/
barChartLabels: any = [];
barChartType: any = String;
barChartData: any = [];
barData: any = [];
barChartOptions: any = {};
barChartLegend: any = Boolean;
barChartPlugins: any = [];

/*PIE VARIABLE*/
pieChartLabels: any = [];
pieChartType: any = String;
pieChartData: any = [];
pieData: any = [];
pieChartOptions: any = {};
pieChartLegend: any = Boolean;
pieChartPlugins: any = [];

/*line VARIABLE*/
lineChartLabels: any = [];
lineChartType: any = String;
lineChartData: any = [];
lineData: any = [];
lineChartOptions: any = {};
lineChartLegend: any = Boolean;
lineChartPlugins: any = [];


/*doughnut VARIABLE*/
doughnutChartLabels: any = [];
doughnutChartType: any = String;
doughnutChartData: any = [];
doughnutData: any = [];
doughnutChartOptions: any = {};
doughnutChartLegend: any = Boolean;
doughnutChartPlugins: any = [];



  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
    this.cargarChartBar();
    this.cargarChartPie();
    this.cargarChartline();
    this.cargarChartdoughnut();
  }


  cargarChartBar() {
    this.barChartPlugins = [pluginDataLabels]; //esto agrega los valores en los items
    this.barChartOptions = {
      scaleShowVerticalLines: true,
      responsive: true,
      maintainAspectRatio: false,
      aspectRatio: 2,
      plugins: {
        datalabels: {
          anchor: 'center',
          align: 'center',
          font: {
            size: 16,
          }
        }
      }
    }
    this.barChartLegend = true;
    //this.barChartType = 'bar';
    this.barChartData = [
      { data: [], label: '' }
    ];
    this.barChartLabels = ["LUNES", "MARTES", "MIERCOLES","JUEVES","VIERNES"]
    this.barData = [];

    //EJEMPLO DE SERVICIO PARA CARGAR LOS LABELS Y LA DATA
    /*this.reporteService.GestionesXUsuario(info).subscribe(
      data => {
        //console.log("la data es", data)
        if (data.result == 'OK') {
          for (var i = 0; i < data.data.length; i++) {
            this.barData.push({
              data: ["LUNES", "MARTES", "MIERCOLES","JUEVES","VIERNES"],
              label: USUARIO,

            })
          }
          this.barChartData = this.barData;
        }
      }
    );*/

    this.barData.push({
      data: ["1","2","3","4","5" ],
      label: "USUARIO 1",
    })

    this.barData.push({
      data: ["4","1","0","2","8" ],
      label: "USUARIO 2",
    })
    this.barChartData = this.barData;
  }


  cargarChartPie() {
    this.pieChartPlugins = [pluginDataLabels]; //esto agrega los valores en los items
    this.pieChartOptions = {
      scaleShowVerticalLines: true,
      responsive: true,
      maintainAspectRatio: false,
      aspectRatio: 2,
      plugins: {
        datalabels: {
          anchor: 'center',
          align: 'center',
          font: {
            size: 16,
          }
        }
      }
    }
    this.pieChartLegend = true;
    //this.pieChartType = 'pie';
    this.pieChartData = [
      { data: [], label: '' }
    ];
    this.pieChartLabels = ["LUNES", "MARTES", "MIERCOLES","JUEVES","VIERNES"]
    this.pieData = [];

    //EJEMPLO DE SERVICIO PARA CARGAR LOS LABELS Y LA DATA
    /*this.reporteService.GestionesXUsuario(info).subscribe(
      data => {
        //console.log("la data es", data)
        if (data.result == 'OK') {
          for (var i = 0; i < data.data.length; i++) {
            this.barData.push({
              data: ["LUNES", "MARTES", "MIERCOLES","JUEVES","VIERNES"],

            })
          }
          this.barChartData = this.barData;
        }
      }
    );*/

    this.pieData.push({
      data: ["1","2","3","4","5" ],
    })

    this.pieChartData = this.pieData;
  }


  cargarChartline() {
    this.lineChartPlugins = [pluginDataLabels]; //esto agrega los valores en los items
    this.lineChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      aspectRatio: 2,
      plugins: {
        datalabels: {
          anchor: 'center',
          align: 'center',
          font: {
            size: 16,
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true
        }
      }
    };
    this.lineChartLegend = true;
    //this.lineChartType = 'line'; // Change to line chart
    this.lineChartData = [
      { data: [], label: '' }
    ];
    this.lineChartLabels = ["LUNES", "MARTES", "MIERCOLES","JUEVES","VIERNES"]
    this.lineData = [];

      //EJEMPLO DE SERVICIO PARA CARGAR LOS LABELS Y LA DATA
    /*this.reporteService.GestionesXUsuario(info).subscribe(
      data => {
        //console.log("la data es", data)
        if (data.result == 'OK') {
          for (var i = 0; i < data.data.length; i++) {
            this.barData.push({
              data: ["LUNES", "MARTES", "MIERCOLES","JUEVES","VIERNES"],
              label: USUARIO,

            })
          }
          this.barChartData = this.barData;
        }
      }
    );*/
  
    this.lineData.push({
      data: [1, 2, 3, 4, 5],
      label: "USUARIO 1",
      borderColor: 'rgba(255, 99, 132, 1)', // Add border color for the line
      fill: false // Set to false to display a line chart
    })
  
    this.lineData.push({
      data: [4, 1, 0, 2, 8],
      label: "USUARIO 2",
      borderColor: 'rgba(54, 162, 235, 1)', // Add border color for the line
      fill: false // Set to false to display a line chart
    })
    this.lineChartData = this.lineData;
  }


  cargarChartdoughnut() {
    this.doughnutChartPlugins = [pluginDataLabels]; //esto agrega los valores en los items
    this.doughnutChartOptions = {
      scaleShowVerticalLines: true,
      responsive: true,
      maintainAspectRatio: false,
      aspectRatio: 2,
      plugins: {
        datalabels: {
          anchor: 'center',
          align: 'center',
          font: {
            size: 16,
          }
        }
      }
    }
    this.doughnutChartLegend = true;
    //this.doughnutChartType = 'doughnut';
    this.doughnutChartData = [
      { data: [], label: '' }
    ];
    this.doughnutChartLabels = ["LUNES", "MARTES", "MIERCOLES","JUEVES","VIERNES"]
    this.doughnutData = [];

    //EJEMPLO DE SERVICIO PARA CARGAR LOS LABELS Y LA DATA
    /*this.reporteService.GestionesXUsuario(info).subscribe(
      data => {
        //console.log("la data es", data)
        if (data.result == 'OK') {
          for (var i = 0; i < data.data.length; i++) {
            this.doughnutData.push({
              data: ["LUNES", "MARTES", "MIERCOLES","JUEVES","VIERNES"],
              label: USUARIO,

            })
          }
          this.doughnutChartData = this.doughnutData;
        }
      }
    );*/

    this.doughnutData.push({
      data: ["1","2","3","4","5" ],
      label: "USUARIO 1",
    })


    this.doughnutChartData = this.doughnutData;
  }
  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/chart/chart.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/chart/chart.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/chart/chart.component.scss.html",'language-html'); 
    }
  }
}
