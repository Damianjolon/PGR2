import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { recursosVarios } from 'app/recursos/recursosVarios';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-alerta',
  templateUrl: './alerta.component.html',
  styleUrls: ['./alerta.component.scss']
})
export class AlertaComponent implements OnInit {
  /*variables para un swal con opciones select*/
  valorSeleccionado: any;
  CatalogodeOpciones: any =[]
  inputOptions: any = {}


  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
  }

  AbrirMsgbox(){
           /* color:number valores,
            0 Blanco
            1 celeste
            2 verde
            3 anaranjado
            4 rojo
            5 rosado
            6 azul
        */
    new recursosVarios().showNotification('top', 'right', 'No se encontraron estados activos', 2);
  }

  AbrirSwalSimple(){
    /*
    tipo: success, error, warning
   */

      Swal.fire("Guardado", "Texto Adicional", "success");
  }



  AbrirSwalRespuesta(){

    Swal.fire({
      icon: "question",
      title: "Esta Seguro de Realizar Esto",
      showConfirmButton: true,
      showCancelButton: true,
      confirmButtonText: "Aceptar",
      denyButtonText: "No guardar",
      confirmButtonColor: "#01579b",
      cancelButtonColor: "#d33"

    }).then((result) => {

      if (result.isConfirmed) {
        Swal.fire("Guardado", "Texto Adicional", "success");
      } else  {
        Swal.fire("Cancelado", "txt", "info");
      }
    });
  }



  AbrirSwalOpciones(){

    this.CatalogodeOpciones = [
      {ID:1, DESCRIPCION:"Opcion 1"},
      {ID:2, DESCRIPCION:"Opcion 2"},
      {ID:3, DESCRIPCION:"Opcion 3"}
    ]

    const showInputOptions = true;

    const swalConfig:any = {
      title: "Titulo",
      showCancelButton: true,
      cancelButtonText: 'Cancel',
      confirmButtonText: 'Confirm',
      preConfirm: (selectedValue: any) => {
        this.valorSeleccionado = selectedValue
      }
    };

    //aqui va el catalogo de opciones 
    this.CatalogodeOpciones.forEach((option: { ID: string | number; DESCRIPCION: any; }) => {
      this.inputOptions[option.ID] = option.DESCRIPCION;
    });

    swalConfig['text'] = 'Seleccione el motivo';
    swalConfig['icon'] = 'info';
    swalConfig['input'] = 'select';
    swalConfig['inputOptions'] = this.inputOptions;

    swalConfig['showConfirmButton'] = true;
    swalConfig['showCancelButton'] = true;
    swalConfig['confirmButtonColor'] = "#01579b";
    swalConfig['cancelButtonColor'] = "#d33";
    swalConfig['confirmButtonText'] = "Aceptar";
    swalConfig['cancelButtonText'] = "Cancelar";

    Swal.fire(swalConfig).then((result: any) => {
      if (result.value) {

          //la validacion se hace debido a que cuando se oculta el select por defecto devuelve true y no lo interpreta el servicio
        // ya que el mismo espera un id tipo numerico, esto para cuando se quiere usar uno solo para varios eventos
        if (typeof this.valorSeleccionado === "boolean"){
          this.valorSeleccionado = 0;
        }
        Swal.fire("Guardado", "Texto Adicional "+this.valorSeleccionado, "success");
        console.log("this.valorSeleccionado",this.valorSeleccionado);
        
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // Realiza acciones adicionales si el usuario canceló la selección
        console.log('Cancelled');

      }    
    });
  }

  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/alerta/alerta.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/alerta/alerta.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/alerta/alerta.component.scss.html",'language-html'); 
    }
  }
}
