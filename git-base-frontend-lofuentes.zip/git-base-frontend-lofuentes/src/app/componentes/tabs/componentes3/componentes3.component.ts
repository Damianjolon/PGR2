import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';

@Component({
  selector: 'app-componentes3',
  templateUrl: './componentes3.component.html',
  styleUrls: ['./componentes3.component.scss']
})
export class Componentes3Component implements OnInit {

  constructor(public dialog: MatDialog,
    private http: HttpClient,
	) { }

  ngOnInit(): void {
  }

  Inicio(){
    console.log("Hola desde mi componente 2")
    
  }
  loadFileContent(x: number){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/componentes3/componentes3.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/componentes3/componentes3.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/componentes3/componentes3.component.scss.html",'language-html'); 
    }
  }
}
