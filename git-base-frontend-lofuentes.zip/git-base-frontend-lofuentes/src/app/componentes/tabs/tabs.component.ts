import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { Componentes1Component } from './componentes1/componentes1.component';
import { Componentes2Component } from './componentes2/componentes2.component';
import { Componentes3Component } from './componentes3/componentes3.component';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent implements OnInit {

  @ViewChild(Componentes1Component, { static: true }) Componentes1Component!: Componentes1Component;
  @ViewChild(Componentes2Component, { static: true }) Componentes2Component!: Componentes2Component;
  @ViewChild(Componentes3Component, { static: true }) Componentes3Component!: Componentes3Component
  
  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
  }

  TabSeleccionado(event: { index: any; }){
    switch ( event.index) {
      case 0:
        this.Componentes1Component.Inicio();
      break;
      case 1:
        this.Componentes2Component.Inicio();
      break;
      case 2:
        this.Componentes3Component.Inicio();
      break;
      default:
        this.Componentes1Component.Inicio();
      break;
  }
}

loadFileContent(x: number){
  if(x==1){
    new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/tabs.component.html",'language-html'); 
  }else if(x==2){
    new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/tabs.component.ts.html",'language-typescript'); 
  }else if(x==3){
    new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/tabs.component.scss.html",'language-html'); 
  }
}


}
