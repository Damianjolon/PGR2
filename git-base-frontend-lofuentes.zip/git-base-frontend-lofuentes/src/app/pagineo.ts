import { Injectable } from "@angular/core"
import { MatPaginatorIntl } from "@angular/material/paginator";
@Injectable()
export class MatPaginatorIntlEspaniol extends MatPaginatorIntl {
    itemsPerPageLabel = 'Registros por página: ';
    firstPageLabel = 'Primera página'
    nextPageLabel = 'Página siguiente';
    previousPageLabel = 'Página anterior';
    lastPageLabel = 'Últina página'

    getRangeLabel = (page: number, pageSize: number, length: number) => {
        return ((page * pageSize) + 1) + ' - ' + ((page * pageSize) + pageSize) + ' de ' + length;
    }
}