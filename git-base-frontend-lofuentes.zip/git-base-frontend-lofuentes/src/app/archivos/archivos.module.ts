import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VerarchivoComponent } from './verarchivo/verarchivo.component';
import { ArchivosRoutingModule } from './verarchivo/archivos-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MaterialModule } from 'app/app.module';



@NgModule({
  imports: [
    CommonModule,
    ArchivosRoutingModule,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatIconModule,
    MatSelectModule,
    MatTableModule,
    MaterialModule,
    ReactiveFormsModule,
  ],
  declarations: [VerarchivoComponent],
})
export class ArchivosModule { }
