import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerarchivoComponent } from './verarchivo.component';

describe('VerarchivoComponent', () => {
  let component: VerarchivoComponent;
  let fixture: ComponentFixture<VerarchivoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VerarchivoComponent]
    });
    fixture = TestBed.createComponent(VerarchivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
