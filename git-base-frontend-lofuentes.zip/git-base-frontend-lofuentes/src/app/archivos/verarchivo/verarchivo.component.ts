import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { ArchivoService } from './archivo.service';


@Component({
  selector: 'app-verarchivo',
  templateUrl: './verarchivo.component.html',
  styleUrls: ['./verarchivo.component.scss']
})
export class VerarchivoComponent implements OnInit {
  fileUrl: SafeUrl | null = null;
  mostrar: boolean = false;
  errorMessage: string | null = null;
  isImage: boolean = false;
  isAudio: boolean = false;
  isPdf: boolean = false;
  isVideo: boolean = false;

//
formulario: FormGroup;

  constructor(
    private Service: ArchivoService,
    private sanitizer: DomSanitizer,private formBuilder: FormBuilder,
    public dialog: MatDialog,
  ) {
     this.formulario = this.formBuilder.group({
      archivo: ['', Validators.required],

    });
  }

  ngOnInit(): void {
//    this.VisualizarDocumentoNAS();
    this.onReset();
    this.formulario.markAllAsTouched();

  }

  async VisualizarDocumentoNAS(id: string ) {
    this.Service.VerArchivoNAS(id).subscribe({
      next: (response: Blob) => {
        try {

          console.log('Response MIME type:', response.type);
          // Determine file type
          this.isImage = response.type.startsWith('image/');
          this.isAudio = response.type.startsWith('audio/') || response.type === 'audio/mpeg';
          this.isVideo = response.type.startsWith('video/') || response.type === 'application/mp4';
          this.isPdf = response.type === 'application/pdf';
          if (!this.isImage && !this.isVideo && !this.isAudio && !this.isPdf) {
            throw new Error('Tipo de archivo no soportado: ' + response.type);
          }

          const objectUrl = URL.createObjectURL(response);
       // Usar la sanitización adecuada según el tipo de archivo
          if (this.isPdf) {
            this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(objectUrl); // Para <iframe>
          } else {
            this.fileUrl = this.sanitizer.bypassSecurityTrustUrl(objectUrl); // Para <img>, <video>, <audio>
          }

          this.mostrar = true;
        } catch (err) {
          this.errorMessage = 'Error al procesar el archivo: ' + (err instanceof Error ? err.message : 'Error desconocido');
          console.error('Error:', err);
        }
      },
      error: (err: any) => {
        this.errorMessage = 'Error al descargar el archivo: ' + err.message;
        console.error('Error al descargar el archivo:', err);
      }
    });
  }

 


  enviar() {

    if (this.formulario.valid) {
       this.errorMessage = null;
      console.log(this.formulario.valid)
      const idArchivo = this.formulario.get('archivo')?.value;
      console.log('ID Archivo:', idArchivo);
      this.VisualizarDocumentoNAS(idArchivo);
    } else {
      this.formulario.markAllAsTouched();

    }
//    this.VisualizarDocumentoNAS('fsdfsdfsd');

  }

  onReset() {
    this.formulario.reset();
  }
  
  errorHandling(control: string, error: string) {
    //return null
    return this.formulario.get(control)?.hasError(error);
  }




  ngOnDestroy(): void {
    if (this.fileUrl) {
      URL.revokeObjectURL(this.fileUrl as string);
    }
  }
}
