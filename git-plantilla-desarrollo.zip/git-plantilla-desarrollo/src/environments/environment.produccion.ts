export const environment = {
  production: true,
  restApiServiceBaseUri:'http://server:8080/CITBASE2/webapi/', // REST Api
  restOAUTH :'http://wsdesacit:8080/OAUTH2/webapi/', //oauth
  restAPIEMAIL:'http://wsdesacit:8080/EMAIL/webapi/',
  restAPIEMAIL2:'http://wsdesacit:8080/EMAIL/webapi/',
  sistemaId :16,  //id sistema  oauth  CITBASE2 16
  sistemaIdOAUTH :2,  //id sistema  oauth
  googleMapsApiKey: 'AIzaSyBpoLWt1A0D59g1Z_Dg7fNQpFsV95OccQY',
  
  Sistema: 'CITBASE2'
};
