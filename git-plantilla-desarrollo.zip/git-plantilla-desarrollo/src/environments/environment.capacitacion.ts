// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  restApiServiceBaseUri:'http://wsdesacit:8080/CITBASE2/webapi/', // REST Api
  restOAUTH :'http://wsdesacit:8080/OAUTH2/webapi/', //oauth
  restAPIEMAIL:'http://wsdesacit:8080/EMAIL/webapi/',
  sistemaId :16,  //id sistema  oauth  CITBASE2 16
  sistemaIdOAUTH :2,  //id sistema  oauth
  googleMapsApiKey: 'AIzaSyBpoLWt1A0D59g1Z_Dg7fNQpFsV95OccQY',
  Sistema: 'CITBASE2'
}
  
