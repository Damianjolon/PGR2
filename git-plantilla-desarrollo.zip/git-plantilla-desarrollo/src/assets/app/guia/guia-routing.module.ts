import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app/app.component';
import { ModuleComponent } from './module/module.component';
import { RoutingComponent } from './routing/routing.component';
import { ServiceComponent } from './service/service.component';

const routes: Routes = [
  {
    path:'App',
    component: AppComponent
  },
  {
    path:'Modulos',
    component: ModuleComponent
  },
  {
    path:'Routing',
    component: RoutingComponent
  },
  {
    path:'Services',
    component: ServiceComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GuiaRoutingModule { }
