#### IMPORTACION DE LIBRERIAS
--------------------------------------------------------------------------
```
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AlertaComponent } from './alerta/alerta.component';
import { CalendarioComponent } from './calendario/calendario.component';
import { CargarDocumentoComponent } from './cargar-documento/cargar-documento.component';
import { CarouselComponent } from './carousel/carousel.component';
import { ChartComponent } from './chart/chart.component';
import { EmailComponent } from './email/email.component';
import { MapsComponent } from './maps/maps.component';
import { ModalComponent } from './modal/modal.component';
import { StepperComponent } from './stepper/stepper.component';
import { TablasComponent } from './tablas/tablas.component';
import { TabsComponent } from './tabs/tabs.component';
import { TimelineComponent } from './timeline/timeline.component';
import { TreeComponent } from './tree/tree.component';
import { VerDocumentoComponent } from './ver-documento/ver-documento.component';


```

#### Agregar rutas
--------------------------------------------------------------------------
```
const routes: Routes = [
  {
    path:'Calendario',
    component: CalendarioComponent
  },
  {
    path:'VerDocumentos',
    component: VerDocumentoComponent
  },
  {
    path:'CargarDocumentos',
    component: CargarDocumentoComponent
  },
  {
    path:'Tablas',
    component: TablasComponent
  },
  {
    path:'Tabs',
    component: TabsComponent
  }, 
  {
    path:'TimeLine',
    component: TimelineComponent
  },
  {
    path:'Chart',
    component: ChartComponent
  },
  {
    path:'Tree',
    component: TreeComponent
  },
  {
    path:'Modal',
    component: ModalComponent
  },
  {
    path:'Maps',
    component: MapsComponent
  },
  {
    path:'Carousel',
    component: CarouselComponent
  },
  {
    path:'Email',
    component: EmailComponent
  },
  {
    path:'Alertas',
    component: AlertaComponent
  },
  {
    path:'Stepper',
    component: StepperComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ComponentesRoutingModule { }
```