import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoutingComponent } from './routing/routing.component';
import { ModuleComponent } from './module/module.component';
import { ServiceComponent } from './service/service.component';
import { AppComponent } from './app/app.component';
import { GuiaRoutingModule } from './guia-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'app/app.module';
import { MatInputModule } from '@angular/material/input';
import { NouisliderModule } from 'ng2-nouislider';
import { TagInputModule } from 'ngx-chips';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [
    RoutingComponent,
    ModuleComponent,
    ServiceComponent,
    AppComponent
  ],
  imports: [
    CommonModule,
    GuiaRoutingModule,
    
    
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    MatInputModule,
    NouisliderModule,
    TagInputModule,
    NgbModule
  ]
})
export class GuiaModule { }
