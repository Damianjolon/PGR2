import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import { AuthGuardService, validarPermisos } from './guardAccesos/auth-guard.service';
import { LoginComponent } from './pages/login/login.component';

export const AppRoutes: Routes = [
  {
    path: '',
    component: AdminLayoutComponent,
    data: { paginas: [33] },
    canActivate: [AuthGuardService],
    children: [
      {
        path: '',
        loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
        canActivate: [AuthGuardService],
        //component:HomeComponent
      },

      // {
      //     path: 'reportes',
      //     loadChildren: './reportes/reportes.module#ReportesModule',
      // },

      {
        path: 'Componentes',
        loadChildren: () => import('./componentes/componentes.module').then(m => m.ComponentesModule),
        //data: { paginas: [33] },
        canActivate: [AuthGuardService]
      },
      {
        path: 'Forms',
        loadChildren: () => import('./forms/forms.module').then(m => m.FormsViewModule),
        //data: { paginas: [33] },
        canActivate: [AuthGuardService]
      },
      {
        path: 'Guia',
        loadChildren: () => import('./guia/guia.module').then(m => m.GuiaModule),
        //data: { paginas: [33] },
        canActivate: [AuthGuardService]
      },



      {
        path: 'Reportes',
        loadChildren: () => import('./reportes/reportes.module').then(m => m.ReportesModule),
        //data: { paginas: [33] },
        canActivate: [AuthGuardService]
      },
      /* {
          path: 'prueba',
          loadChildren: './prueba/prueba.module#PruebaModule',
        //  data: {paginas: [33]},
     //     canActivate:[validarPermisos]
      }, */
      /* {
          path: '**',
          redirectTo: ''
      } */
    ]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '**',
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forRoot(AppRoutes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
