import { HttpClient } from "@angular/common/http";
import { MatDialog } from "@angular/material/dialog";
import { ViewcodeComponent } from "app/componentes/viewcode/viewcode.component";

declare const $: any;

export class CodeViewerClass{
    
    constructor(private http: HttpClient, public dialog: MatDialog){}


    loadFileContent(path, type) {
        if (!path) {
          alert('Por favor ingresa el nombre del archivo');
          return;
        }

        //const filePath = `assets/componentes/${this.fileName}`;
    
        this.http.get(path, { responseType: 'text' }).subscribe(
          (data) => {
            // Abre el modal y le pasa los datos
            this.dialog.open(ViewcodeComponent, {
              data: {
                fileContent: data,
                fileName: this.getFileNameFromPath(path),
                type: type
              },
              panelClass: ["bounce-in-top"]
            });
          },
          (error) => {
            console.error('Error al cargar el archivo', error);
          }
        );
      }

      getFileNameFromPath(filePath: string): string {
        // Buscar la posición del último slash ('/') en la ruta
        const lastSlashIndex = filePath.lastIndexOf('/');
      
        // Extraer y retornar el nombre del archivo desde la última aparición del slash
        return filePath.substring(lastSlashIndex + 1);
      }


}