
import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';
import { CommonService } from '../../service/CommonService.service';


@Component({
  selector: 'app-vistaprevia_imagen',
  templateUrl: './vistaprevia_imagen.component.html',
  styleUrls: ['./vistaprevia_imagen.component.scss']
})
export class Vistaprevia_imagenComponent implements OnInit {
  @ViewChild('pdfViewerAutoLoad') pdfViewerAutoLoad: { pdfSrc: any; refresh: () => void; };
  pdfSrc: Blob = null;
  pageurl: SafeResourceUrl;
  datos: any = {}
  count: number = 0;
  type_file: any
  file_pdf: any
  docxUrl: string;

  @Input() arrayBuffer: ArrayBuffer = null;
  @Output() validaPDF = new EventEmitter<number>();
  constructor(
    private commonService: CommonService) { }

  ngOnInit() {
    this.onLoad(this.arrayBuffer);
  }

  async onLoad(array: any) {

    this.PDFValido(array);
    if (array.name.endsWith('.doc') || array.name.endsWith('.docx')) {
      this.docxUrl = './assets/img/word.png'
    } else if (array.name.endsWith('.pdf')) {
      this.docxUrl = './assets/img/pdf.png'
    }
    

  }


  async PDFValido(file: any) {
    this.commonService.PDFValido(file).subscribe((data) => {
      if (data.result == "ERROR") {
        this.count = 1;
        this.validaPDF.emit(this.count);
      }
    });
  }
}
