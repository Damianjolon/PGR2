export interface FIRMANTE {
    ID_FIRMANTE: string;
    NOMBRE_CARGO: string;
    NOMBRE_FIRMANTE: string;
    NOMBRE_DEPENDENCIA: string;
    PRIORIDAD: string;
    LLEVA_SELLO: string;
    VISTO_BUENO: string;
    CARNET: string;
    FIRMA_INTERNA: string;
  }
  