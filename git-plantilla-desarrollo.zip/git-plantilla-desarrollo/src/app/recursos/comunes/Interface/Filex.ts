export interface Filex extends Blob {
    File: any;
    lastModified: number;
    lastModifiedDate: Date;
    name: string;
    webkitRelativePath: string;
    observ: string;
  }