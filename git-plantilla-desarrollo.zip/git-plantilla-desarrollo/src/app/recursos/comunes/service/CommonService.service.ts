import { catchError } from 'rxjs/operators';

import { Observable, of } from 'rxjs';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppconfigService } from 'app/appconfig.service';
import { recursosVarios } from 'app/recursos/recursosVarios';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http: HttpClient, private appSettings: AppconfigService) { }

  PDFValido(data: any): Observable<any> {
    var formData = new FormData();
    formData.append("P_FILE", data);
    return this.http.post<any>(this.appSettings.restApiServiceBaseUri + 'File/PDFValido', formData)
      .pipe(
        catchError(this.handleError('PDFValido', []))
      );
  }


  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      new recursosVarios().showNotification('top', 'right', '<h4>Error Metodo ' + operation.toString() + '</h3>', 4)
      return of(result as T);
    };
  }

}
