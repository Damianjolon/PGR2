import { HttpClient, HttpEvent } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { Filex } from 'app/recursos/comunes/Interface/Filex';
import { recursosVarios } from 'app/recursos/recursosVarios';
import { Subscription } from 'rxjs';
import Swal from 'sweetalert2';
import { ComponentesService } from '../componentes.service';

@Component({
  selector: 'app-cargar-documento',
  templateUrl: './cargar-documento.component.html',
  styleUrls: ['./cargar-documento.component.scss']
})
export class CargarDocumentoComponent implements OnInit {

    dataInfo: any;

    /* upload file*/
    accept = '*'
    files: Filex[] = []
    progress: number
    hasBaseDropZoneOver: boolean = false
    httpEvent: HttpEvent<{}>
    httpEmitter: Subscription
    lastFileAt: Date
    sendableFormData: FormData
    selectedFiles: FileList;
    parentCount: number = 0;
    filecount: number = 0;
    


  constructor(private componentesService: ComponentesService,
    public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
  }

  Guardar() {
    if (this.files.length <= 0) {
      new recursosVarios().showNotification('top', 'right', 'Se debe de adjuntar al menos un documento', 3);
      return;
    }

    const formData = new FormData();
    if (this.files) {
      this.files.forEach(async element => {
        formData.append('files', element);
      })
    } else {
      console.error('No files selected.');
    }

    //aqui se arma un json cualquiera que se necesite
    this.dataInfo =  {ID_ESTADO: 1} 

    const blobSolicitud = new Blob([JSON.stringify(this.dataInfo)], {
      type: 'application/json',
    });


    formData.append('solicitud', blobSolicitud, 'solicitud');
    this.componentesService.InsDocumento(formData).subscribe(data => {
      if (data.id > 0) {
        this.onReset();
        Swal.fire("Guardado Exitosaemte", data.msj, "success");
      } else {
        Swal.fire("Error Al Guardar", data.msj, "warning");
      }
    });


  }




  /**************AGREGAR PARA QUE PUEDA HACER EL DRAG / SELECT BUTTON****************** */
  onFileSelected(event: any) {
    const files: FileList = event.target.files;
    this.handleFiles(files);
    console.log(" this.parentCount1", this.parentCount);
  }

  onDropFile(event: any) {
    event.preventDefault();
    const files: FileList = event.dataTransfer.files;
    this.handleFiles(files);
    console.log(" this.parentCount2", this.parentCount);
  }

  onDragOver(event: any) {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
    event.target.classList.add('drag-over');
    console.log(" this.parentCount3", this.parentCount);
  }

  onDragLeave(event: any) {
    event.target.classList.remove('drag-over');
    console.log(" this.parentCount4", this.parentCount);
  }

  handleFiles(files: FileList) {
    // Maneja los archivos seleccionados o arrastrados aquí
    console.log(" this.parentCount5", this.parentCount);
    console.log(files);
  }
  onFileChange(event) {
    this.selectedFiles = event.target.files;
  }

  ErrorPDF(count: any) {
    this.parentCount += count;    
    if (this.parentCount > 0) {
      this.parentCount -= 1;    
      this.files.splice((this.parentCount - 1), 1);
      new recursosVarios().showNotification('top', 'right', 'Lo sentimos!!", "El documento se encuentra dañado', 3);
    }
  }
  /******************************* */
  onReset() {
    this.files = [];
    this.dataInfo={}
  }


  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/cargar-documento/cargar-documento.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/cargar-documento/cargar-documento.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/cargar-documento/cargar-documento.component.scss.html",'language-html'); 
    }
  }
}
