import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import hljs from 'highlight.js';
import 'highlight.js/lib/languages/xml'; // for HTML highlighting
import 'highlight.js/lib/languages/typescript'; // for TypeScript highlighting

@Component({
  selector: 'app-viewcode',
  templateUrl: './viewcode.component.html',
  styleUrls: ['./viewcode.component.scss']
})
export class ViewcodeComponent implements OnInit {
  syntaxClass: string;
  highlightedContent: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: { fileContent: string, fileName: string, type: string },
  public dialogRef: MatDialogRef<ViewcodeComponent>,) {
    console.log('Data:', data); // log the data object to the console
  }

  ngOnInit(): void {
    this.syntaxClass = this.data.type;
    this.highlightedContent = this.highlightCode(this.data.fileContent, this.data.type).code;
  }

  highlightCode(code: string, language: string): { code: string, language: string } {
    let lang = language;
    if (language === 'language-html') {
      lang = 'xml'; // map language-html to xml for highlighting
    }
    if (language === 'language-typescript') {
      lang = 'typescript'; // map language-typescript to typescript for highlighting
    }
    const highlightedCode = hljs.highlight(code, { language: lang }).value;
    return { code: highlightedCode, language: lang };
  }

  cerrarModal(): void {
    this.dialogRef.close();
  }
}