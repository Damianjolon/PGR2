import { HttpClient } from "@angular/common/http";
import { Component, OnInit, ViewChild } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { MatStepper } from "@angular/material/stepper";
import { CodeViewerClass } from "app/recursos/comunes/functions/codeviewer";
import Swal from "sweetalert2";

@Component({
  selector: "app-stepper",
  templateUrl: "./stepper.component.html",
  styleUrls: ["./stepper.component.scss"],
})
export class StepperComponent implements OnInit {
  @ViewChild("stepper") stepper!: MatStepper; // Referencia al stepper
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;

  constructor(private _formBuilder: FormBuilder,
    public dialog: MatDialog,
    private http: HttpClient,) {
    // Inicialización de los formularios con validadores
    this.firstFormGroup = this._formBuilder.group({
      valor1: ["", Validators.required],
      valor2: ["", Validators.required],
    });

    this.secondFormGroup = this._formBuilder.group({
      valor3: ["", Validators.required],
      valor4: ["", Validators.required],
    });
  }

  ngOnInit(): void {}

  // Función para verificar la validación de campos requeridos
  checkStepValidation(formGroup: FormGroup): void {
    const currentStepLabel =
      this.stepper?.steps.toArray()[this.stepper.selectedIndex]?.label ||
      "this step";

    if (!formGroup.valid) {
      Swal.fire({
        icon: "warning",
        title: "Campos Incompletos",
        text: `Por favor complete todos los campos requeridos en ${currentStepLabel}.`,
      });
      return;
    } else {
      this.stepper.selected.completed = true;
      this.stepper.next();
    }
  }

  //Funcion para dar siguiente
  nextClicked(event) {
    console.log("eventeventevent", event);

    if (event == 0) {
      this.checkStepValidation(this.firstFormGroup);
      /*this.stepper.selected.completed = true;
      this.stepper.next();*/
    }

    if (event == 1) {
      this.checkStepValidation(this.secondFormGroup);
    }

    if (event == 2) {
    }
  }

  //Funcion para regresar
  backClicked() {
    this.stepper.previous();
    this.stepper.selected.completed = false;
  }

  EnviarFormulario() {
    Swal.fire("Enviado", "Guardado con Exito", "success");
    this.resetStepper();
  }

  resetStepper(): void {
    this.stepper.reset();
  }



  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/stepper/stepper.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/stepper/stepper.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/stepper/stepper.component.scss.html",'language-html'); 
    }
  }
}
