import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AppconfigService } from 'app/appconfig.service';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';

@Component({
  selector: 'app-maps',
  templateUrl: './maps.component.html',
  styleUrls: ['./maps.component.scss']
})
export class MapsComponent implements OnInit {

  center: google.maps.LatLngLiteral; 
  title:string;
  zoom = 16;
  iconUrl: string = "assets/img/aca.png";

  constructor(public dialog: MatDialog,
    private http: HttpClient,) { 
    
  }

  ngOnInit(): void {
    this.cargar_Info();
  }

  cargar_Info(){
    this.center = { lat: 14.91167, lng: -91.36111} 
    this.title = 'Hola Mundo'
  }

  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/maps/maps.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/maps/maps.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/maps/maps.component.scss.html",'language-html'); 
    }
  }
}
