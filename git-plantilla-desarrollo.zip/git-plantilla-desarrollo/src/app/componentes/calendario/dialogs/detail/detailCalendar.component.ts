import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-detailCalendar',
  templateUrl: './detailCalendar.component.html',
  styleUrls: ['./detailCalendar.component.scss']
})
export class DetailCalendarComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<DetailCalendarComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,) {

  }

  ngOnInit(): void {

  }

  Guardar(){
    Swal.fire({
      title: "Guardado Exitosamente",
      text: "Puede continuar con el proceso!",
      icon: "success"
    });
  }

  cerrarModal(): void {
    this.dialogRef.close();
  }

  onReset() {
  }
}
