import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent implements OnInit {
  data_timeline: any = [];
  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
    this.Cargar_Data_Timeline();
  }

  Cargar_Data_Timeline() {

    //AQUI SE LLAMA AL SERVICIO PARA EL ARRAY
    /*this.catalogoService.Estados(info).subscribe(data => {
      if (data.id > 0) {
        this.data_timeline = data.data; 
      }
    });*/

    //EJEMPLO
    this.data_timeline = [
      {
          "EXPEDIENTE_NUMERO_UNICO": "01002-2023-00694",
          "TIPO_RECHAZO": "",
          "ID_ESTADO_EXPEDIENTE": "6",
          "USUARIO_ASIGNADO_ID": "22415",
          "USUARIO_ASIGNADO": "ECOCHOA",
          "FECHA_PROCESO": "12/07/2024 09:41:03",
          "ID_MESA_TRABAJO": "663",
          "USUARIO_ASIGNA_ID": "25850",
          "ESTADO": "Finalizar Tramite",
          "ICONO": "pan_tool\n",
          "ID_HOJA_RUTA": "967",
          "USUARIO_ASIGNA": "JFVILLATORO",
          "COLOR": "info\n",
          "NUMERO": "7",
          "USUARIO_ASIGNA_NOMBRE": "JOSE FRANCISCO VILLATORO RUIZ",
          "OBSERVACIONES": "",
          "USUARIO_ASIGNADO_NOMBRE": "EVELYN CARINA OCHOA ORELLANA",
          "ID_EXPEDIENTE": "501"
      },
      {
          "EXPEDIENTE_NUMERO_UNICO": "01002-2023-00694",
          "TIPO_RECHAZO": "",
          "ID_ESTADO_EXPEDIENTE": "2",
          "USUARIO_ASIGNADO_ID": "22415",
          "USUARIO_ASIGNADO": "ECOCHOA",
          "FECHA_PROCESO": "12/07/2024 09:30:07",
          "ID_MESA_TRABAJO": "663",
          "USUARIO_ASIGNA_ID": "25850",
          "ESTADO": "Tramite",
          "ICONO": "gesture\n",
          "ID_HOJA_RUTA": "966",
          "USUARIO_ASIGNA": "JFVILLATORO",
          "COLOR": "warning\n",
          "NUMERO": "6",
          "USUARIO_ASIGNA_NOMBRE": "JOSE FRANCISCO VILLATORO RUIZ",
          "OBSERVACIONES": "",
          "USUARIO_ASIGNADO_NOMBRE": "EVELYN CARINA OCHOA ORELLANA",
          "ID_EXPEDIENTE": "501"
      },
      {
          "EXPEDIENTE_NUMERO_UNICO": "01002-2023-00694",
          "TIPO_RECHAZO": "",
          "ID_ESTADO_EXPEDIENTE": "122",
          "USUARIO_ASIGNADO_ID": "22415",
          "USUARIO_ASIGNADO": "ECOCHOA",
          "FECHA_PROCESO": "12/07/2024 09:27:24",
          "ID_MESA_TRABAJO": "663",
          "USUARIO_ASIGNA_ID": "25850",
          "ESTADO": "ASIGNAR VISTA",
          "ICONO": "check_circle\n",
          "ID_HOJA_RUTA": "965",
          "USUARIO_ASIGNA": "JFVILLATORO",
          "COLOR": "danger\n",
          "NUMERO": "5",
          "USUARIO_ASIGNA_NOMBRE": "JOSE FRANCISCO VILLATORO RUIZ",
          "OBSERVACIONES": "",
          "USUARIO_ASIGNADO_NOMBRE": "EVELYN CARINA OCHOA ORELLANA",
          "ID_EXPEDIENTE": "501"
      },
      {
          "EXPEDIENTE_NUMERO_UNICO": "01002-2023-00694",
          "TIPO_RECHAZO": "",
          "ID_ESTADO_EXPEDIENTE": "2",
          "USUARIO_ASIGNADO_ID": "25850",
          "USUARIO_ASIGNADO": "JFVILLATORO",
          "FECHA_PROCESO": "12/07/2024 09:24:31",
          "ID_MESA_TRABAJO": "662",
          "USUARIO_ASIGNA_ID": "17636",
          "ESTADO": "Tramite",
          "ICONO": "gesture\n",
          "ID_HOJA_RUTA": "964",
          "USUARIO_ASIGNA": "AMEJIA",
          "COLOR": "warning\n",
          "NUMERO": "4",
          "USUARIO_ASIGNA_NOMBRE": "ANA LETICIA MEJIA CHAICOJ",
          "OBSERVACIONES": "",
          "USUARIO_ASIGNADO_NOMBRE": "JOSE FRANCISCO VILLATORO RUIZ",
          "ID_EXPEDIENTE": "501"
      },
      {
          "EXPEDIENTE_NUMERO_UNICO": "01002-2023-00694",
          "TIPO_RECHAZO": "",
          "ID_ESTADO_EXPEDIENTE": "43",
          "USUARIO_ASIGNADO_ID": "25850",
          "USUARIO_ASIGNADO": "JFVILLATORO",
          "FECHA_PROCESO": "12/07/2024 09:22:46",
          "ID_MESA_TRABAJO": "662",
          "USUARIO_ASIGNA_ID": "17636",
          "ESTADO": "Proyecto de resolución a revisión",
          "ICONO": "feedback\n",
          "ID_HOJA_RUTA": "963",
          "USUARIO_ASIGNA": "AMEJIA",
          "COLOR": "success\n",
          "NUMERO": "3",
          "USUARIO_ASIGNA_NOMBRE": "ANA LETICIA MEJIA CHAICOJ",
          "OBSERVACIONES": "",
          "USUARIO_ASIGNADO_NOMBRE": "JOSE FRANCISCO VILLATORO RUIZ",
          "ID_EXPEDIENTE": "501"
      },
      {
          "EXPEDIENTE_NUMERO_UNICO": "01002-2023-00694",
          "TIPO_RECHAZO": "",
          "ID_ESTADO_EXPEDIENTE": "2",
          "USUARIO_ASIGNADO_ID": "17636",
          "USUARIO_ASIGNADO": "AMEJIA",
          "FECHA_PROCESO": "12/07/2024 09:19:03",
          "ID_MESA_TRABAJO": "661",
          "USUARIO_ASIGNA_ID": "28441",
          "ESTADO": "Tramite",
          "ICONO": "gesture\n",
          "ID_HOJA_RUTA": "962",
          "USUARIO_ASIGNA": "BSANTIAGO",
          "COLOR": "warning\n",
          "NUMERO": "2",
          "USUARIO_ASIGNA_NOMBRE": "BRYAN ABRAHAM SANTIAGO MEJIA",
          "OBSERVACIONES": "Prueba 12/07/2024",
          "USUARIO_ASIGNADO_NOMBRE": "ANA LETICIA MEJIA CHAICOJ",
          "ID_EXPEDIENTE": "501"
      },
      {
          "EXPEDIENTE_NUMERO_UNICO": "01002-2023-00694",
          "TIPO_RECHAZO": "",
          "ID_ESTADO_EXPEDIENTE": "121",
          "USUARIO_ASIGNADO_ID": "17636",
          "USUARIO_ASIGNADO": "AMEJIA",
          "FECHA_PROCESO": "12/07/2024 09:17:16",
          "ID_MESA_TRABAJO": "661",
          "USUARIO_ASIGNA_ID": "28441",
          "ESTADO": "PARA CALIFICAR",
          "ICONO": "assignment_ind\n",
          "ID_HOJA_RUTA": "961",
          "USUARIO_ASIGNA": "BSANTIAGO",
          "COLOR": "info\n",
          "NUMERO": "1",
          "USUARIO_ASIGNA_NOMBRE": "BRYAN ABRAHAM SANTIAGO MEJIA",
          "OBSERVACIONES": "Prueba 12/07/2024",
          "USUARIO_ASIGNADO_NOMBRE": "ANA LETICIA MEJIA CHAICOJ",
          "ID_EXPEDIENTE": "501"
      }
  ]

  }


  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/timeline/timeline.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/timeline/timeline.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/timeline/timeline.component.scss.html",'language-html'); 
    }
  }
  
}
