import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';

@Component({
  selector: 'app-componentes1',
  templateUrl: './componentes1.component.html',
  styleUrls: ['./componentes1.component.scss']
})
export class Componentes1Component implements OnInit {

  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
  }

  Inicio(){
    console.log( "Hola mundo desde el componente 1");
     
  }

  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/componentes1/componentes1.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/componentes1/componentes1.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/componentes/tabs/componentes1/componentes1.component.scss.html",'language-html'); 
    }
  }

}
