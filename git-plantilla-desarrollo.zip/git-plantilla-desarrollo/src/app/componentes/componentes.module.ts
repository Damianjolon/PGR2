import { NgModule, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'app/app.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { NouisliderModule } from 'ng2-nouislider';
import { TagInputModule } from 'ngx-chips';
import { MatTableModule } from '@angular/material/table';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ngfModule } from 'angular-file';
import { MatInputModule } from '@angular/material/input';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { CalendarioComponent } from './calendario/calendario.component';
import { ModalComponent } from './modal/modal.component';
import { VerDocumentoComponent } from './ver-documento/ver-documento.component';
import { CargarDocumentoComponent } from './cargar-documento/cargar-documento.component';
import { ComponentesRoutingModule } from './componentes-routing.module';
import { DetailCalendarComponent } from './calendario/dialogs/detail/detailCalendar.component';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';

import { MatTabsModule } from '@angular/material/tabs';
import { TextMaskModule } from 'angular2-text-mask';
import { MatCardModule } from '@angular/material/card';
import { Vistaprevia_imagenComponent } from '../recursos/comunes/view/vistaprevia_imagen/vistaprevia_imagen.component';
import { TablasComponent } from './tablas/tablas.component';
import { TabsComponent } from './tabs/tabs.component';
import { TimelineComponent } from './timeline/timeline.component';
import { Componentes1Component } from './tabs/componentes1/componentes1.component';
import { Componentes2Component } from './tabs/componentes2/componentes2.component';
import { Componentes3Component } from './tabs/componentes3/componentes3.component';
import { ConselectinputComponent } from './tablas/conselectinput/conselectinput.component';
import { SinselectinputComponent } from './tablas/sinselectinput/sinselectinput.component';
import { SimpleComponent } from './tablas/simple/simple.component';
import { ChartComponent } from './chart/chart.component';
import { ChartsModule } from 'ng2-charts';
import { TreeComponent } from './tree/tree.component';
import { MatTreeModule } from '@angular/material/tree';
import { CarouselComponent } from './carousel/carousel.component';
import { MapsComponent } from './maps/maps.component';
import { EmailComponent } from './email/email.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { GoogleMapsModule } from '@angular/google-maps';
import { AppconfigService } from 'app/appconfig.service';
import { DialogComponent } from './modal/dialogs/dialog/dialog.component';
import { FirmaComponent } from './modal/dialogs/firma/firma.component';
import { AlertaComponent } from './alerta/alerta.component';
import { ViewcodeComponent } from './viewcode/viewcode.component';
import { StepperComponent } from './stepper/stepper.component';
import { MatStepperModule } from '@angular/material/stepper';
import { MatButtonModule } from '@angular/material/button';




@NgModule({
  declarations: [
    CalendarioComponent,
    ModalComponent,
    DetailCalendarComponent,
    VerDocumentoComponent,
    CargarDocumentoComponent,
    Vistaprevia_imagenComponent,
    TablasComponent,
    TabsComponent,
    TimelineComponent,
    Componentes1Component,
    Componentes2Component,
    Componentes3Component,
    ConselectinputComponent,
    SinselectinputComponent,
    SimpleComponent,
    ChartComponent,
    TreeComponent,
    CarouselComponent,
    MapsComponent,
    EmailComponent,
    DialogComponent,
    FirmaComponent,
    AlertaComponent,
    ViewcodeComponent,
    StepperComponent
  ],
  imports: [
    //componentes para formularios
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    MatIconModule,
    NouisliderModule,
    TagInputModule,
    MatTableModule,
    MatSelectModule,
    MatFormFieldModule,
    ngfModule,
    MatInputModule,
    NgxMatSelectSearchModule,
    NgxMaterialTimepickerModule,
    
    //routing
    ComponentesRoutingModule,

    //calendario
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),

    //pddfviewer
    NgxExtendedPdfViewerModule,
        TextMaskModule,
        
        NgxMatSelectSearchModule,
        MatCardModule,

        //chatjs
        ChartsModule,

        //Tree
        MatTreeModule,

        //carousel
        NgbModule,

        //google maps
        //GoogleMapsModule  

        GoogleMapsModule,
        MatStepperModule,
        MatButtonModule,

  ], 
  entryComponents:[CalendarioComponent, DetailCalendarComponent,DialogComponent, FirmaComponent,ViewcodeComponent],
  bootstrap:[],
  providers: [{
    provide: 'googleMapsApiKey',
    useValue: 'AIzaSyBpoLWt1A0D59g1Z_Dg7fNQpFsV95OccQY',
  },],
})
export class ComponentesModule { }
