import { Component, OnInit, ViewChild } from "@angular/core";
import { ReportesService } from "../reportes.service";

@Component({
  selector: "app-itext",
  templateUrl: "./itext.component.html",
  styleUrls: ["./itext.component.scss"],
})
export class ItextComponent implements OnInit {
  Url:Blob
  mostrar:boolean = false
  constructor(private reportesService: ReportesService,) { }

  ngOnInit(): void {
    this.VisualizarDocumentoNAS()
  }

  async VisualizarDocumentoNAS() {
   await this.reportesService.VerDocumentoNAS().subscribe((response: Blob) => {
      //const url = URL.createObjectURL(response);
      this.Url = response;
      this.mostrar = true
    }, (error) => {
        console.error('Error al descargar el archivo:', error);
    });
}

}
