import { Component, OnInit } from '@angular/core';
import { ReportesService } from '../reportes.service';

@Component({
  selector: 'app-itext-memoria',
  templateUrl: './itext-memoria.component.html',
  styleUrls: ['./itext-memoria.component.scss']
})
export class ItextMemoriaComponent implements OnInit {
  Url:Blob
  mostrar:boolean = false
  constructor(private reportesService: ReportesService) { }

  ngOnInit(): void {
    this.VisualizarDocumentoMEMORIA()
  }
  async VisualizarDocumentoMEMORIA() {
   await this.reportesService.VerDocumentoMEMORIA().subscribe((response: Blob) => {
      //const url = URL.createObjectURL(response);
      this.Url = response;
      this.mostrar = true
    }, (error) => {
        console.error('Error al descargar el archivo:', error);
    });
}
}