import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportesRoutingModule } from './reportes-routing.module';
import { ListadoComponent } from './listado/listado.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../app.module';
import { SelectModule } from 'ng2-select';


import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { NouisliderModule } from 'ng2-nouislider';
import { TagInputModule } from 'ngx-chips';
import { ChartsModule} from 'ng2-charts';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';


import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';
import { ItextComponent } from './itext/itext.component';
import { ItextMemoriaComponent } from './itext-memoria/itext-memoria.component';

@NgModule({
  imports: [
    CommonModule,
    ReportesRoutingModule,
    MaterialModule,
    ReactiveFormsModule, 
    FormsModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    NouisliderModule,
    TagInputModule,
    MaterialModule,
    MatTableModule,
    MatSelectModule,
    MatFormFieldModule,
    ChartsModule,
    NgxMatSelectSearchModule,
    NgxExtendedPdfViewerModule,
   // MatDatepickerModule
  ],
  declarations: [ListadoComponent, ItextComponent, ItextMemoriaComponent ],
  entryComponents: []

})
export class ReportesModule { }
