import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AppconfigService } from 'app/appconfig.service';

@Injectable({
  providedIn: 'root'
})
export class ReportesService {

  constructor(private http: HttpClient,private appSettings:AppconfigService) { }

  getParametros(idReporte): Observable<any>{
    return this.http.get<any>(this.appSettings.restOAUTH+'Reportes/Reporte/'+idReporte+'/getParametrosReporte')
    .pipe(
      catchError(this.handleError('getParametros', []))
    );
  }

  getCatalogoReporteDinamico(dato): Observable<any>{
    return this.http.post<any>(this.appSettings.restOAUTH+'Reportes/Reporte/getCatalogoReporteDinamico',dato)
    .pipe(
      catchError(this.handleError('getCatalogoReporteDinamico', []))
    );
  }


  insReporteSolicitud(objetoReporte): Observable<any>{
    return this.http.post<any>(this.appSettings.restOAUTH+'Reportes/insReporteSolicitud',objetoReporte)
    .pipe(
      catchError(this.handleError('insReporteSolicitud', []))
    );
  }


  GestionesXUsuario(data): Observable<any>{
    return this.http.post<any>(this.appSettings.restApiServiceBaseUri+'Estadistica/GestionesXUsuario',data)
    .pipe(
      catchError(this.handleError('GestionesXUsuario', []))
    );
  }

  ResumenXLetrado(data): Observable<any>{
    return this.http.post<any>(this.appSettings.restApiServiceBaseUri+'Estadistica/ResumenXLetrado',data)
    .pipe(
      catchError(this.handleError('ResumenXLetrado', []))
    );
  }

  VerDocumento(id_documento, id_tipo):  any{
    return this.http.get( this.appSettings.restApiServiceBaseUri+'File/documento/'+id_documento+'/tipo/'+id_tipo+'/VerDocumento',
      { responseType: 'blob' });
  }


  VerDocumentoNAS():  any{
    return this.http.get( this.appSettings.restApiServiceBaseUri+'File/Itext_PdfNas',
      { responseType: 'blob' });
  }

  VerDocumentoMEMORIA():  any{
    return this.http.get( this.appSettings.restApiServiceBaseUri+'File/Itext_PdfMemoria',
      { responseType: 'blob' });
  }
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.log('xx error xx', error.message)
      
      return of(result as T);
    };
  }
  private getURL(urlServer,Servicio){
    return urlServer+Servicio;
  }
}
