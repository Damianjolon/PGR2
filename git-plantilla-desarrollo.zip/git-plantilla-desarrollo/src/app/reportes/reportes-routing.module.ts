import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { validarPermisos } from 'app/guardAccesos/auth-guard.service';
import { ItextMemoriaComponent } from './itext-memoria/itext-memoria.component';
import { ItextComponent } from './itext/itext.component';
import { ListadoComponent } from './listado/listado.component';




//acceso a las constantes guardadas en loca Storage
var localStorageService = localStorage;
var constantes:any = JSON.parse(atob(localStorageService.getItem("CONSTANTES")));

const routes: Routes = [
  {
    path: 'Listado',
    component: ListadoComponent,
    data: {paginas: [constantes.MENU_REPORTES]}, //ID DEL MENU EN OAUTH
    //canActivate:[validarPermisos]
  },
  {
    path: 'Itext',
    component: ItextComponent,
    //data: {paginas: [constantes.MENU_REPORTES]}, //ID DEL MENU EN OAUTH
    //canActivate:[validarPermisos]
  },
  {
    path: 'itext_en_memoria',
    component: ItextMemoriaComponent,
    //data: {paginas: [constantes.MENU_REPORTES]}, //ID DEL MENU EN OAUTH
    //canActivate:[validarPermisos]
  },
  {
    path: '',
    redirectTo: ''
  },
  // {
  //   path:'Dashboard',
  //   component: DashboardComponent
  // },
  // {
  //   path:'GenerarReportes',
  //   component: ListadoComponent
  // }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportesRoutingModule { }
