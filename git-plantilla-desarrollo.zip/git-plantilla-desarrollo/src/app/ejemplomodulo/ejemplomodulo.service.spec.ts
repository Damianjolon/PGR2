import { TestBed } from '@angular/core/testing';

import { EjemplomoduloService } from './ejemplomodulo.service';

describe('EjemplomoduloService', () => {
  let service: EjemplomoduloService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EjemplomoduloService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
