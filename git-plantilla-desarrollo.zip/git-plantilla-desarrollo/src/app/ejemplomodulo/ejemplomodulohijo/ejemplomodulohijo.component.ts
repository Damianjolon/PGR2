import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ejemplomodulohijo',
  templateUrl: './ejemplomodulohijo.component.html',
  styleUrls: ['./ejemplomodulohijo.component.scss']
})
export class EjemplomodulohijoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
