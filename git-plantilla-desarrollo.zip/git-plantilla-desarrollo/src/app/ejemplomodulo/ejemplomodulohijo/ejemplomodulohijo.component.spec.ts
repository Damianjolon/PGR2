import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EjemplomodulohijoComponent } from './ejemplomodulohijo.component';

describe('EjemplomodulohijoComponent', () => {
  let component: EjemplomodulohijoComponent;
  let fixture: ComponentFixture<EjemplomodulohijoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EjemplomodulohijoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EjemplomodulohijoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
