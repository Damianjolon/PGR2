import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EjemplomodulohijoComponent } from './ejemplomodulohijo/ejemplomodulohijo.component';



@NgModule({
  declarations: [
    EjemplomodulohijoComponent
  ],
  imports: [
    CommonModule
  ]
})
export class EjemplomoduloModule { }
