import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-componente1',
  templateUrl: './componente1.component.html',
  styleUrls: ['./componente1.component.scss']
})
export class Componente1Component implements OnInit {

  constructor(private router: Router) {}

  ngOnInit(): void {
  }

  regresar() {
    this.router.navigate(['/Guia/Routing_Child']); // Redirige a la ruta padre, que es Componente0
  }
}
