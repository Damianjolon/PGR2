import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoutingchildRoutingModule } from './routingchild-routing.module';
import { Componente1Component } from './componente1/componente1.component';
import { Componente2Component } from './componente2/componente2.component';
import { Componente0Component } from './componente0/componente0.component';


@NgModule({
  declarations: [
    Componente1Component,
    Componente2Component,
    Componente0Component
  ],
  imports: [
    CommonModule,
    RoutingchildRoutingModule
  ]
})
export class RoutingchildModule { }
