import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-componente0',
  templateUrl: './componente0.component.html',
  styleUrls: ['./componente0.component.scss']
})
export class Componente0Component implements OnInit {

  constructor(private router: Router) {}

  ngOnInit(): void {
  }

  irAComponente1() {
    this.router.navigate(['/Guia/Routing_Child/Componente1']);
  }

  irAComponente2() {
    this.router.navigate(['/Guia/Routing_Child/Componente2']);
  }

}
