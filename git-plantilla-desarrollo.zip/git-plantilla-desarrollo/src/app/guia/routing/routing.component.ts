import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import * as marked from "marked";

@Component({
  selector: 'app-routing',
  templateUrl: './routing.component.html',
  styleUrls: ['./routing.component.scss']
})
export class RoutingComponent implements OnInit {
  markdownContent_ar: SafeHtml = "";
  markdownContent_crm: SafeHtml = "";
  markdownContent_crcm: SafeHtml = "";

  constructor(private http: HttpClient, private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    this.http
      .get("assets/app/guia/routing/app.routing.txt", { responseType: "text" })
      .subscribe(
        (data: string) => {
          this.markdownContent_ar = this.sanitizer.bypassSecurityTrustHtml(
            marked.parse(data)
          );
        },
        (error) => {
          console.error("Error al cargar el archivo Markdown:", error);
        }
      );

      this.http
      .get("assets/app/guia/routing/componentes-routing.module.txt", { responseType: "text" })
      .subscribe(
        (data: string) => {
          this.markdownContent_crm = this.sanitizer.bypassSecurityTrustHtml(
            marked.parse(data)
          );
        },
        (error) => {
          console.error("Error al cargar el archivo Markdown:", error);
        }
      );

      this.http
      .get("assets/app/guia/routing/guia-routing.module.txt", { responseType: "text" })
      .subscribe(
        (data: string) => {
          this.markdownContent_crcm = this.sanitizer.bypassSecurityTrustHtml(
            marked.parse(data)
          );
        },
        (error) => {
          console.error("Error al cargar el archivo Markdown:", error);
        }
      );
  }
}
