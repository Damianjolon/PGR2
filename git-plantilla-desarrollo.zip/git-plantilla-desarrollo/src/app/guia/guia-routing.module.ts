import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app/app.component';
import { InstalacionComponent } from './instalacion/instalacion.component';
import { ModuleComponent } from './module/module.component';
import { RoutingComponent } from './routing/routing.component';
import { RoutingchildModule } from './routingchild/routingchild.module';
import { ServiceComponent } from './service/service.component';

const routes: Routes = [
  {
    path:'Instalacion',
    component: InstalacionComponent
  },
  {
    path:'App',
    component: AppComponent
  },
  {
    path:'Modulos',
    component: ModuleComponent
  },
  {
    path:'Routing',
    component: RoutingComponent
  },
  {
    path:'Routing_Child',
    loadChildren: () => import('./routingchild/routingchild.module').then(m => m.RoutingchildModule)  
  },
  {
    path:'Services',
    component: ServiceComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GuiaRoutingModule { }
