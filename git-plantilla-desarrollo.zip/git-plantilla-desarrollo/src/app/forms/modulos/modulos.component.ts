import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';

@Component({
  selector: 'app-modulos',
  templateUrl: './modulos.component.html',
  styleUrls: ['./modulos.component.scss']
})
export class ModulosComponent implements OnInit {

  constructor( public dialog: MatDialog,
    private http: HttpClient,  ) { }

  ngOnInit(): void {
  }


  
  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/modulos/forms.module.ts.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/modulos/componentes.module.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/modulos/componentes-routing.module.ts.html",'language-html'); 
    }else if(x==4){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/modulos/componentes.service.ts.html",'language-html'); 
    }else if(x==5){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/modulos/app.routing.ts.html",'language-html'); 
    }
  }

}
