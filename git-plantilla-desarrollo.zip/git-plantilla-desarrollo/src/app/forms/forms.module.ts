import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../app.module';
import { SelectModule } from 'ng2-select';


import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { NouisliderModule } from 'ng2-nouislider';
import { TagInputModule } from 'ngx-chips';
import { ChartsModule} from 'ng2-charts';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';

import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';
import { InputsComponent } from './inputs/inputs.component';
import { FormngmodelComponent } from './formngmodel/formngmodel.component';
import { FormvalidatorComponent } from './formvalidator/formvalidator.component';
import { FormsRoutingModule } from './forms-routing.module';
import { MatInputModule } from '@angular/material/input';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTabsModule } from '@angular/material/tabs';
import { ngfModule } from 'angular-file';
import { MatButtonModule } from '@angular/material/button';
import { MatStepperModule } from '@angular/material/stepper';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatNativeDateModule } from '@angular/material/core';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { DatepickeryearComponent } from './inputs/datepickeryear/datepickeryear.component';
import { TextMaskModule } from 'angular2-text-mask';
import { IconsComponent } from './icons/icons.component';
import { DocumentacionComponent } from './documentacion/documentacion.component';
import { ModulosComponent } from './modulos/modulos.component';


@NgModule({
  declarations: [
    InputsComponent,
    FormngmodelComponent,
    FormvalidatorComponent,
    DatepickeryearComponent,
    IconsComponent,
    DocumentacionComponent,
    ModulosComponent
  ],
  imports: [
    CommonModule,
    FormsRoutingModule,
    
    
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    MatInputModule,
    NouisliderModule,
    TagInputModule,
    NgbModule,
    HttpClientModule,
    MatToolbarModule,
    MatTabsModule,
    
    MatDatepickerModule,
    ngfModule,
    MatButtonModule,
    MatStepperModule,
    MatFormFieldModule,
    MatNativeDateModule,

        
    //PARA EL RELOJ
    NgxMaterialTimepickerModule,
    
    //DIRECTIVAS PARA EL SELECT
    NgxMatSelectSearchModule,
    MatSelectModule,

    //mascara
    TextMaskModule
  ]
})
export class FormsViewModule { }
