import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-formvalidator',
  templateUrl: './formvalidator.component.html',
  styleUrls: ['./formvalidator.component.scss']
})
export class FormvalidatorComponent implements OnInit {
  formulario: FormGroup;
  verContrasena = false;
  observaciones = '';
  hide = true;
  cuiMask = [/[0-9]/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  telefonoMask = [/[0-9]/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  fecha_nacMask = [/[0-9]/, /\d/,'/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/];
  maxLength = 200;

  /*catalgo deñ select*/
  catalogoGenero: any = [];
  ctrlGenero = new FormControl();
  filterGenero: Observable<any[]>;


  constructor(private formBuilder: FormBuilder,
    public dialog: MatDialog,
    private http: HttpClient,) {
    this.formulario = this.formBuilder.group({
      nombres: ['', Validators.required],
      apellidos: ['', Validators.required],
      direccion: ['', Validators.required],
      cui: ['', Validators.required],
      telefono: ['', Validators.required],
      password: ['', Validators.required],
      observaciones: ['', Validators.required],
      email: ['', Validators.required],
      fechaNacimiento: ['', Validators.required],
      ID_GENERO: ['', Validators.required],
    });
   }

  ngOnInit(): void {
    this.onReset();
    this.formulario.markAllAsTouched();
    this.cargarGeneros()
  }

  //carga el catalgo 
  cargarGeneros() {
    var info = [
      {
        ID_GENERO: "1",
        GENERO: 'Masculino'
      }, 
      {
        ID_GENERO: "2",
        GENERO: 'Femenino'
      },
      {
        ID_GENERO: "3",
        GENERO: 'S/A'
      },
    ];

    this.catalogoGenero = info;
    this.filterGenero= this.ctrlGenero.valueChanges.pipe(startWith(""),map((value) => this._filterGenero(value))
    );
  }


  validarFormulario() {

    

  }

  onReset() {
    this.formulario.reset();
  }
  
  errorHandling(control: string, error: string) {
    return this.formulario.get(control).hasError(error);
  }


  private _filterGenero(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.catalogoGenero.filter((data) => data.GENERO.toLowerCase().indexOf(filterValue) === 0
    );
  }


  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/formvalidator/formvalidator.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/formvalidator/formvalidator.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/formvalidator/formvalidator.component.scss.html",'language-html'); 
    }
  }
  
  
}
