import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-formngmodel',
  templateUrl: './formngmodel.component.html',
  styleUrls: ['./formngmodel.component.scss']
})
export class FormngmodelComponent implements OnInit {
  verContrasena = false;
  observaciones = '';
  datos:any ={};
  hide = true;
  cuiMask = [/[0-9]/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  telefonoMask = [/[0-9]/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  fecha_nacMask = [/[0-9]/, /\d/,'/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/];
  genderOptions = ['Masculino', 'Femenino', 'N/S'];
  maxLength = 200;

  /*catalgo deñ select*/
  catalogoGenero: any = [];
  ctrlGenero = new FormControl();
  filterGenero: Observable<any[]>;

  constructor(public dialog: MatDialog,
    private http: HttpClient,
	) { }

  ngOnInit(): void {
    this.cargarGeneros();
  }

  cargarGeneros() {
    var info = [
      {
        ID_GENERO: "1",
        GENERO: 'Masculino'
      }, 
      {
        ID_GENERO: "2",
        GENERO: 'Femenino'
      },
      {
        ID_GENERO: "3",
        GENERO: 'S/A'
      },
    ];

    this.catalogoGenero = info;
    this.filterGenero= this.ctrlGenero.valueChanges.pipe(startWith(""),map((value) => this._filterGenero(value))
    );
  }


  validarFormulario() {

  }

  onReset() {
    this.datos = {}
  }

  private _filterGenero(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.catalogoGenero.filter(
      (data) => data.GENERO.toLowerCase().indexOf(filterValue) === 0
    );
  }

  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/formngmodel/formngmodel.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/formngmodel/formngmodel.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/formngmodel/formngmodel.component.scss.html",'language-html'); 
    }
  }
  

}
