import { HttpClient } from '@angular/common/http';
import { Component,OnInit, ViewChild } from '@angular/core';
import { FormControl} from '@angular/forms';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE,} from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { CodeViewerClass } from 'app/recursos/comunes/functions/codeviewer';
import { FORMAT_YYYY } from 'app/recursos/comunes/Interface/FORMAT_YYYY';
import moment from 'moment';
import * as _moment from 'moment';
import { Moment } from "moment";

@Component({
  selector: 'app-datepickeryear',
  templateUrl: './datepickeryear.component.html',
  styleUrls: ['./datepickeryear.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: FORMAT_YYYY },
  ],
})
export class DatepickeryearComponent implements OnInit { 
  date = new FormControl(moment());
  maxDate = new Date();
  
  constructor(public dialog: MatDialog,
    private http: HttpClient,) { }

  ngOnInit(): void {
  }


  chosenYearHandler(normalizedYear: Moment, pickeryear: any) {
    const ctrlValue = this.date.value;
    ctrlValue.year(normalizedYear.year());
    this.date.setValue(ctrlValue);
    pickeryear.close();
    console.log("El año seleccionado es: ",moment(this.date.value).year());
    console.log("El año seleccionado en formato picker: ",ctrlValue);
  }

  loadFileContent(x){
    if(x==1){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/inputs/datepickeryear/datepickeryear.component.html",'language-html'); 
    }else if(x==2){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/inputs/datepickeryear/datepickeryear.component.ts.html",'language-typescript'); 
    }else if(x==3){
      new CodeViewerClass(this.http, this.dialog).loadFileContent("assets/app/forms/inputs/datepickeryear/datepickeryear.component.scss.html",'language-html'); 
    }
  }
  
}
